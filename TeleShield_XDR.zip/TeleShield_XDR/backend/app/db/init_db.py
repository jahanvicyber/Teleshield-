"""
Creates all tables and seeds default roles, an admin user, and a small
set of fraud-detection patterns so the platform is usable immediately
after first boot.
"""
from app.core.logging import get_logger
from app.db.database import Base, SessionLocal, engine
from app.models.fraud_pattern import FraudPattern
from app.models.role import Role
from app.models.user import User
from app.services.user_service import create_user, get_user_by_employee_id

logger = get_logger(__name__)

DEFAULT_ROLES = [
    ("Administrator", "Full system access"),
    ("Investigator", "Investigates cases and analyses evidence"),
    ("Digital Forensic Analyst", "Performs deep media/call forensic analysis"),
    ("Supervisor", "Oversees investigators and approves case actions"),
    ("Cyber Cell Officer", "Front-line officer handling call/number triage"),
    ("Auditor", "Read-only access to audit trails and reports"),
]

DEFAULT_PATTERNS = [
    {
        "name": "OTP Scam",
        "category": "OTP Scam",
        "description": "Caller pressures the victim to share a one-time password.",
        "keywords": "otp,one time password,share the code,verification code",
        "weight": 35.0,
    },
    {
        "name": "KYC Fraud",
        "category": "KYC Fraud",
        "description": "Caller impersonates a bank asking to 're-verify' KYC.",
        "keywords": "kyc,re-verify,account will be blocked,update your kyc",
        "weight": 30.0,
    },
    {
        "name": "Loan Bait",
        "category": "Loan Bait",
        "description": "Unsolicited instant loan offer, often with upfront fees.",
        "keywords": "instant loan,processing fee,pre-approved loan,loan app",
        "weight": 25.0,
    },
    {
        "name": "Job Offer Scam",
        "category": "Job Offer",
        "description": "Fake work-from-home job offer requesting an upfront deposit.",
        "keywords": "work from home,registration fee,part time job,earn daily",
        "weight": 20.0,
    },
    {
        "name": "Impersonation",
        "category": "Impersonation",
        "description": "Caller impersonates a government official / tax department.",
        "keywords": "income tax department,arrest warrant,digital arrest,customs department",
        "weight": 40.0,
    },
]


def init_db() -> None:
    Base.metadata.create_all(bind=engine)
    logger.info("Database tables ensured.")

    db = SessionLocal()
    try:
        # Seed roles
        role_map: dict[str, Role] = {}
        for name, description in DEFAULT_ROLES:
            role = db.query(Role).filter(Role.name == name).first()
            if not role:
                role = Role(name=name, description=description)
                db.add(role)
                db.commit()
                db.refresh(role)
                logger.info("Seeded role: %s", name)
            role_map[name] = role

        # Seed default admin user
        if not get_user_by_employee_id(db, "ADMIN001"):
            admin = create_user(
                db,
                employee_id="ADMIN001",
                full_name="System Administrator",
                email="admin@teleshield.gov.in",
                password="ChangeMe@123",
                agency="TeleShield XDR HQ",
                department="Platform Administration",
                role_id=role_map["Administrator"].id,
                is_superuser=True,
            )
            logger.warning(
                "Seeded default admin user 'ADMIN001' / 'ChangeMe@123' (id=%s) — change this password immediately.",
                admin.id,
            )

        # Seed fraud detection patterns
        if db.query(FraudPattern).count() == 0:
            for pattern in DEFAULT_PATTERNS:
                db.add(FraudPattern(**pattern))
            db.commit()
            logger.info("Seeded %d default fraud patterns.", len(DEFAULT_PATTERNS))
    finally:
        db.close()


if __name__ == "__main__":
    init_db()
