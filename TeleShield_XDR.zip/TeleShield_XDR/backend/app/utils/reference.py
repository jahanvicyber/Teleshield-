"""
Helpers for generating human-readable reference numbers (CS-2041, EV-7712...).
"""
import random
import string


def gen_reference(prefix: str) -> str:
    suffix = "".join(random.choices(string.digits, k=4))
    return f"{prefix}-{suffix}"
