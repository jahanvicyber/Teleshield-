"""
Blacklist / whitelist number entries.
"""
from sqlalchemy.orm import Session

from app.models.number_list import NumberListEntry
from app.models.user import User


def list_entries(db: Session, *, list_type: str, skip: int = 0, limit: int = 100) -> list[NumberListEntry]:
    return (
        db.query(NumberListEntry)
        .filter(NumberListEntry.list_type == list_type)
        .order_by(NumberListEntry.created_at.desc())
        .offset(skip)
        .limit(limit)
        .all()
    )


def add_entry(db: Session, *, list_type: str, phone_number: str, reason: str | None,
              added_by: User | None) -> NumberListEntry:
    entry = NumberListEntry(
        list_type=list_type,
        phone_number=phone_number,
        reason=reason,
        added_by_id=added_by.id if added_by else None,
    )
    db.add(entry)
    db.commit()
    db.refresh(entry)
    return entry


def get_entry(db: Session, entry_id: int) -> NumberListEntry | None:
    return db.query(NumberListEntry).filter(NumberListEntry.id == entry_id).first()


def remove_entry(db: Session, entry: NumberListEntry) -> None:
    db.delete(entry)
    db.commit()
