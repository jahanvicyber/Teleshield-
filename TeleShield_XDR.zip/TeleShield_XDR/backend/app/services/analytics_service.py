"""
Dashboard / analytics aggregation queries.
"""
from collections import Counter
from datetime import datetime, timedelta, timezone

from sqlalchemy import func
from sqlalchemy.orm import Session

from app.models.call_log import CallLog
from app.models.case import Case
from app.models.evidence import Evidence
from app.models.user import User


def build_dashboard_summary(db: Session) -> dict:
    total_calls = db.query(func.count(CallLog.id)).scalar() or 0
    high_risk = db.query(func.count(CallLog.id)).filter(CallLog.risk_level == "High").scalar() or 0
    critical = db.query(func.count(CallLog.id)).filter(CallLog.risk_level == "Critical").scalar() or 0
    open_cases = db.query(func.count(Case.id)).filter(Case.status != "Closed").scalar() or 0
    evidence_count = db.query(func.count(Evidence.id)).scalar() or 0
    investigators_online = db.query(func.count(User.id)).filter(User.is_active.is_(True)).scalar() or 0

    kpis = [
        {"key": "calls", "label": "Total Calls Analysed", "value": total_calls},
        {"key": "high", "label": "High Risk Calls", "value": high_risk, "tone": "warning"},
        {"key": "critical", "label": "Critical Threats", "value": critical, "tone": "danger"},
        {"key": "cases", "label": "Open Cases", "value": open_cases},
        {"key": "evidence", "label": "Evidence Uploaded", "value": evidence_count, "tone": "success"},
        {"key": "online", "label": "Investigators Online", "value": investigators_online, "tone": "success"},
    ]

    now = datetime.now(timezone.utc)
    daily_trend = []
    for i in range(13, -1, -1):
        day_start = now - timedelta(days=i)
        day_label = day_start.strftime("%d %b")
        threats = (
            db.query(func.count(CallLog.id))
            .filter(func.date(CallLog.created_at) == day_start.date())
            .scalar()
            or 0
        )
        blocked = (
            db.query(func.count(CallLog.id))
            .filter(
                func.date(CallLog.created_at) == day_start.date(),
                CallLog.status == "Closed",
            )
            .scalar()
            or 0
        )
        daily_trend.append({"label": day_label, "threats": threats, "blocked": blocked})

    category_rows = (
        db.query(CallLog.category, func.count(CallLog.id))
        .filter(CallLog.category.isnot(None))
        .group_by(CallLog.category)
        .all()
    )
    scam_categories = [{"name": name, "value": count} for name, count in category_rows]

    risk_rows = db.query(CallLog.risk_level, func.count(CallLog.id)).group_by(CallLog.risk_level).all()
    risk_distribution = [{"name": name, "value": count} for name, count in risk_rows]

    return {
        "kpis": kpis,
        "daily_trend": daily_trend,
        "scam_categories": scam_categories,
        "risk_distribution": risk_distribution,
    }


def carrier_breakdown(db: Session) -> list[dict]:
    rows = (
        db.query(CallLog.carrier, func.count(CallLog.id))
        .filter(CallLog.carrier.isnot(None))
        .group_by(CallLog.carrier)
        .order_by(func.count(CallLog.id).desc())
        .all()
    )
    return [{"name": carrier, "flagged": count} for carrier, count in rows]
