"""
In-app notification business logic.
"""
from sqlalchemy import or_
from sqlalchemy.orm import Session

from app.models.notification import Notification


def list_notifications(db: Session, *, user_id: int, skip: int = 0, limit: int = 50) -> list[Notification]:
    return (
        db.query(Notification)
        .filter(or_(Notification.user_id == user_id, Notification.user_id.is_(None)))
        .order_by(Notification.created_at.desc())
        .offset(skip)
        .limit(limit)
        .all()
    )


def create_notification(db: Session, **fields) -> Notification:
    notification = Notification(**fields)
    db.add(notification)
    db.commit()
    db.refresh(notification)
    return notification


def mark_read(db: Session, notification: Notification) -> Notification:
    notification.is_read = True
    db.commit()
    db.refresh(notification)
    return notification


def get_notification(db: Session, notification_id: int) -> Notification | None:
    return db.query(Notification).filter(Notification.id == notification_id).first()
