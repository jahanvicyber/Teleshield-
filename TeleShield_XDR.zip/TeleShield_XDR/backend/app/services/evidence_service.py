"""
Evidence locker & chain-of-custody business logic.
"""
from sqlalchemy.orm import Session

from app.models.evidence import CustodyEvent, Evidence
from app.models.user import User
from app.utils.reference import gen_reference


def list_evidence(db: Session, *, skip: int = 0, limit: int = 100,
                   case_id: int | None = None) -> list[Evidence]:
    query = db.query(Evidence)
    if case_id is not None:
        query = query.filter(Evidence.case_id == case_id)
    return query.order_by(Evidence.created_at.desc()).offset(skip).limit(limit).all()


def get_evidence(db: Session, evidence_id: int) -> Evidence | None:
    return db.query(Evidence).filter(Evidence.id == evidence_id).first()


def create_evidence(db: Session, *, uploaded_by: User | None, **fields) -> Evidence:
    evidence_number = gen_reference("EV")
    while db.query(Evidence).filter(Evidence.evidence_number == evidence_number).first():
        evidence_number = gen_reference("EV")
    evidence = Evidence(
        evidence_number=evidence_number,
        uploaded_by_id=uploaded_by.id if uploaded_by else None,
        **fields,
    )
    db.add(evidence)
    db.commit()
    db.refresh(evidence)

    add_custody_event(db, evidence=evidence, action="Uploaded", officer=uploaded_by)
    return evidence


def add_custody_event(db: Session, *, evidence: Evidence, action: str, officer: User | None,
                       location: str | None = None, digital_signature: str | None = None) -> CustodyEvent:
    event = CustodyEvent(
        evidence_id=evidence.id,
        action=action,
        officer_id=officer.id if officer else None,
        location=location,
        digital_signature=digital_signature,
    )
    db.add(event)
    if action == "Verified":
        evidence.custody_status = "Verified"
    elif action == "Transferred":
        evidence.custody_status = "Transferred"
    elif action == "Archived":
        evidence.custody_status = "Archived"
    db.commit()
    db.refresh(event)
    return event


def delete_evidence(db: Session, evidence: Evidence) -> None:
    db.delete(evidence)
    db.commit()
