"""
Investigation case business logic.
"""
from sqlalchemy.orm import Session

from app.models.case import Case
from app.utils.reference import gen_reference


def list_cases(db: Session, *, skip: int = 0, limit: int = 100,
                status: str | None = None, priority: str | None = None) -> list[Case]:
    query = db.query(Case)
    if status:
        query = query.filter(Case.status == status)
    if priority:
        query = query.filter(Case.priority == priority)
    return query.order_by(Case.created_at.desc()).offset(skip).limit(limit).all()


def get_case(db: Session, case_id: int) -> Case | None:
    return db.query(Case).filter(Case.id == case_id).first()


def create_case(db: Session, **fields) -> Case:
    case_number = gen_reference("CS")
    while db.query(Case).filter(Case.case_number == case_number).first():
        case_number = gen_reference("CS")
    case = Case(case_number=case_number, **fields)
    db.add(case)
    db.commit()
    db.refresh(case)
    return case


def update_case(db: Session, case: Case, **fields) -> Case:
    for key, value in fields.items():
        if value is not None and hasattr(case, key):
            setattr(case, key, value)
    db.commit()
    db.refresh(case)
    return case


def delete_case(db: Session, case: Case) -> None:
    db.delete(case)
    db.commit()
