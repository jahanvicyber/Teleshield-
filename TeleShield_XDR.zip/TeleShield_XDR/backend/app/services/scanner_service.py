"""
AI scanner engine — heuristic risk scoring for numbers/calls/media using
FraudPattern keyword rules. This is a deterministic stand-in for a real
ML model so the platform is fully functional out of the box; swap the
score_target() internals for a real model/API call when ready.
"""
import json

from sqlalchemy.orm import Session

from app.models.fraud_pattern import FraudPattern, ScanResult
from app.models.number_list import NumberListEntry


def _verdict_from_score(score: float) -> str:
    if score >= 85:
        return "Critical"
    if score >= 60:
        return "High"
    if score >= 30:
        return "Medium"
    return "Low"


def score_target(db: Session, *, target_type: str, target_reference: str,
                  text_sample: str | None = None) -> ScanResult:
    score = 5.0
    matched_pattern: FraudPattern | None = None
    matched_keywords: list[str] = []

    # Blacklist / whitelist short-circuit for phone numbers.
    if target_type in ("number", "call"):
        blacklisted = (
            db.query(NumberListEntry)
            .filter(NumberListEntry.phone_number == target_reference, NumberListEntry.list_type == "blacklist")
            .first()
        )
        whitelisted = (
            db.query(NumberListEntry)
            .filter(NumberListEntry.phone_number == target_reference, NumberListEntry.list_type == "whitelist")
            .first()
        )
        if whitelisted:
            score = 2.0
        elif blacklisted:
            score = 92.0

    if text_sample:
        sample_lower = text_sample.lower()
        patterns = db.query(FraudPattern).filter(FraudPattern.is_active.is_(True)).all()
        for pattern in patterns:
            keywords = [k.strip().lower() for k in (pattern.keywords or "").split(",") if k.strip()]
            hits = [k for k in keywords if k in sample_lower]
            if hits:
                score += pattern.weight
                matched_keywords.extend(hits)
                if matched_pattern is None or pattern.weight > matched_pattern.weight:
                    matched_pattern = pattern

    score = max(0.0, min(100.0, score))
    result = ScanResult(
        target_type=target_type,
        target_reference=target_reference,
        ai_score=score,
        verdict=_verdict_from_score(score),
        matched_pattern_id=matched_pattern.id if matched_pattern else None,
        details=json.dumps({"matched_keywords": matched_keywords}),
    )
    db.add(result)
    db.commit()
    db.refresh(result)
    return result


def list_scan_results(db: Session, *, skip: int = 0, limit: int = 100) -> list[ScanResult]:
    return db.query(ScanResult).order_by(ScanResult.created_at.desc()).offset(skip).limit(limit).all()


def list_patterns(db: Session) -> list[FraudPattern]:
    return db.query(FraudPattern).order_by(FraudPattern.id).all()


def create_pattern(db: Session, **fields) -> FraudPattern:
    pattern = FraudPattern(**fields)
    db.add(pattern)
    db.commit()
    db.refresh(pattern)
    return pattern
