"""
Report generation records.
"""
from sqlalchemy.orm import Session

from app.models.report import Report
from app.models.user import User


def list_reports(db: Session, *, skip: int = 0, limit: int = 100) -> list[Report]:
    return db.query(Report).order_by(Report.created_at.desc()).offset(skip).limit(limit).all()


def create_report(db: Session, *, generated_by: User | None, **fields) -> Report:
    report = Report(generated_by_id=generated_by.id if generated_by else None, **fields)
    db.add(report)
    db.commit()
    db.refresh(report)
    return report


def get_report(db: Session, report_id: int) -> Report | None:
    return db.query(Report).filter(Report.id == report_id).first()
