"""
Call log business logic — records + AI risk scoring integration.
"""
from sqlalchemy.orm import Session

from app.models.call_log import CallLog
from app.services.scanner_service import score_target
from app.utils.reference import gen_reference


def list_call_logs(db: Session, *, skip: int = 0, limit: int = 100,
                    risk_level: str | None = None) -> list[CallLog]:
    query = db.query(CallLog)
    if risk_level:
        query = query.filter(CallLog.risk_level == risk_level)
    return query.order_by(CallLog.created_at.desc()).offset(skip).limit(limit).all()


def get_call_log(db: Session, call_log_id: int) -> CallLog | None:
    return db.query(CallLog).filter(CallLog.id == call_log_id).first()


def create_call_log(db: Session, *, phone_number: str, country: str | None = None,
                     carrier: str | None = None, duration_seconds: int = 0,
                     transcript: str | None = None, officer_id: int | None = None) -> CallLog:
    call_reference = gen_reference("INV")
    while db.query(CallLog).filter(CallLog.call_reference == call_reference).first():
        call_reference = gen_reference("INV")

    scan = score_target(db, target_type="call", target_reference=phone_number, text_sample=transcript)

    call_log = CallLog(
        call_reference=call_reference,
        phone_number=phone_number,
        country=country,
        carrier=carrier,
        duration_seconds=duration_seconds,
        risk_score=scan.ai_score,
        risk_level=scan.verdict,
        status="Analysing",
        officer_id=officer_id,
    )
    db.add(call_log)
    db.commit()
    db.refresh(call_log)
    return call_log


def update_call_log_status(db: Session, call_log: CallLog, status: str) -> CallLog:
    call_log.status = status
    db.commit()
    db.refresh(call_log)
    return call_log
