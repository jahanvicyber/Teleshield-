"""
Threat intelligence lookup & storage.
"""
from sqlalchemy.orm import Session

from app.models.threat_intel import ThreatIntelEntry


def list_entries(db: Session, *, skip: int = 0, limit: int = 100) -> list[ThreatIntelEntry]:
    return (
        db.query(ThreatIntelEntry)
        .order_by(ThreatIntelEntry.threat_score.desc())
        .offset(skip)
        .limit(limit)
        .all()
    )


def lookup(db: Session, indicator_value: str) -> ThreatIntelEntry | None:
    return db.query(ThreatIntelEntry).filter(ThreatIntelEntry.indicator_value == indicator_value).first()


def upsert_entry(db: Session, **fields) -> ThreatIntelEntry:
    existing = lookup(db, fields["indicator_value"])
    if existing:
        for key, value in fields.items():
            if value is not None:
                setattr(existing, key, value)
        existing.report_count += 1
        db.commit()
        db.refresh(existing)
        return existing

    entry = ThreatIntelEntry(**fields, report_count=1)
    db.add(entry)
    db.commit()
    db.refresh(entry)
    return entry
