"""
User business logic: create, authenticate, update.
"""
from sqlalchemy.orm import Session

from app.core.security import hash_password, verify_password
from app.models.user import User


def get_user_by_employee_id(db: Session, employee_id: str) -> User | None:
    return db.query(User).filter(User.employee_id == employee_id).first()


def get_user_by_email(db: Session, email: str) -> User | None:
    return db.query(User).filter(User.email == email).first()


def get_user(db: Session, user_id: int) -> User | None:
    return db.query(User).filter(User.id == user_id).first()


def list_users(db: Session, skip: int = 0, limit: int = 100) -> list[User]:
    return db.query(User).offset(skip).limit(limit).all()


def create_user(db: Session, *, employee_id: str, full_name: str, email: str,
                 password: str, agency: str | None = None, department: str | None = None,
                 role_id: int | None = None, is_superuser: bool = False) -> User:
    user = User(
        employee_id=employee_id,
        full_name=full_name,
        email=email,
        hashed_password=hash_password(password),
        agency=agency,
        department=department,
        role_id=role_id,
        is_superuser=is_superuser,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


def authenticate_user(db: Session, employee_id: str, password: str) -> User | None:
    user = get_user_by_employee_id(db, employee_id)
    if not user:
        return None
    if not verify_password(password, user.hashed_password):
        return None
    return user


def update_user(db: Session, user: User, **fields) -> User:
    password = fields.pop("password", None)
    for key, value in fields.items():
        if value is not None and hasattr(user, key):
            setattr(user, key, value)
    if password:
        user.hashed_password = hash_password(password)
    db.commit()
    db.refresh(user)
    return user


def delete_user(db: Session, user: User) -> None:
    db.delete(user)
    db.commit()
