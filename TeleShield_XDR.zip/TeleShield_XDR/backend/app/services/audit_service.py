"""
Audit logging business logic.
"""
from sqlalchemy.orm import Session

from app.models.audit_log import AuditLog
from app.models.user import User


def log_action(
    db: Session,
    *,
    user: User | None,
    action: str,
    resource: str | None = None,
    ip_address: str | None = None,
    device: str | None = None,
    status: str = "Success",
) -> AuditLog:
    entry = AuditLog(
        user_id=user.id if user else None,
        action=action,
        resource=resource,
        ip_address=ip_address,
        device=device,
        status=status,
    )
    db.add(entry)
    db.commit()
    db.refresh(entry)
    return entry


def list_logs(
    db: Session,
    *,
    skip: int = 0,
    limit: int = 100,
    user_id: int | None = None,
    action: str | None = None,
) -> list[AuditLog]:
    query = db.query(AuditLog)
    if user_id is not None:
        query = query.filter(AuditLog.user_id == user_id)
    if action:
        query = query.filter(AuditLog.action.ilike(f"%{action}%"))
    return query.order_by(AuditLog.timestamp.desc()).offset(skip).limit(limit).all()
