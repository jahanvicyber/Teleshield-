"""
TeleShield XDR Backend
"""