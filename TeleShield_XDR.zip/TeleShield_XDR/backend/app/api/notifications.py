"""
In-app notification endpoints.
"""
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.core.dependencies import get_current_user, get_db
from app.models.user import User
from app.schemas.notification import NotificationCreate, NotificationOut
from app.services import notification_service

router = APIRouter(prefix="/notifications", tags=["Notifications"])


@router.get("", response_model=list[NotificationOut])
def list_my_notifications(skip: int = 0, limit: int = 50, db: Session = Depends(get_db),
                           current_user: User = Depends(get_current_user)):
    return notification_service.list_notifications(db, user_id=current_user.id, skip=skip, limit=limit)


@router.post("", response_model=NotificationOut, status_code=status.HTTP_201_CREATED)
def create_notification(payload: NotificationCreate, db: Session = Depends(get_db),
                         current_user: User = Depends(get_current_user)):
    return notification_service.create_notification(db, **payload.model_dump())


@router.patch("/{notification_id}/read", response_model=NotificationOut)
def mark_read(notification_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    notification = notification_service.get_notification(db, notification_id)
    if not notification:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Notification not found")
    return notification_service.mark_read(db, notification)
