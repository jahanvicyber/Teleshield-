"""
Call log endpoints — telecom records + AI risk scoring.
"""
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.core.dependencies import get_current_user, get_db
from app.models.user import User
from app.schemas.call_log import CallLogCreate, CallLogOut
from app.services import audit_service, call_log_service

router = APIRouter(prefix="/call-logs", tags=["Call Logs"])


@router.get("", response_model=list[CallLogOut])
def list_call_logs(
    skip: int = 0,
    limit: int = 100,
    risk_level: str | None = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return call_log_service.list_call_logs(db, skip=skip, limit=limit, risk_level=risk_level)


@router.get("/{call_log_id}", response_model=CallLogOut)
def get_call_log(call_log_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    item = call_log_service.get_call_log(db, call_log_id)
    if not item:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Call log not found")
    return item


@router.post("", response_model=CallLogOut, status_code=status.HTTP_201_CREATED)
def create_call_log(
    payload: CallLogCreate,
    transcript: str | None = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    item = call_log_service.create_call_log(
        db, officer_id=current_user.id, transcript=transcript, **payload.model_dump()
    )
    audit_service.log_action(db, user=current_user, action="CALL_ANALYSED", resource=f"call:{item.call_reference}")
    return item


@router.patch("/{call_log_id}/status", response_model=CallLogOut)
def update_status(
    call_log_id: int,
    new_status: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    item = call_log_service.get_call_log(db, call_log_id)
    if not item:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Call log not found")
    updated = call_log_service.update_call_log_status(db, item, new_status)
    audit_service.log_action(db, user=current_user, action="CALL_STATUS_UPDATED", resource=f"call:{item.call_reference}")
    return updated
