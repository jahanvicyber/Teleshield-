"""
Evidence locker & chain-of-custody endpoints.
"""
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.core.dependencies import get_current_user, get_db
from app.models.user import User
from app.schemas.evidence import CustodyEventCreate, CustodyEventOut, EvidenceCreate, EvidenceOut
from app.services import audit_service, evidence_service

router = APIRouter(prefix="/evidence", tags=["Evidence Locker"])


@router.get("", response_model=list[EvidenceOut])
def list_evidence(
    skip: int = 0,
    limit: int = 100,
    case_id: int | None = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return evidence_service.list_evidence(db, skip=skip, limit=limit, case_id=case_id)


@router.get("/{evidence_id}", response_model=EvidenceOut)
def get_evidence(evidence_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    item = evidence_service.get_evidence(db, evidence_id)
    if not item:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Evidence not found")
    return item


@router.post("", response_model=EvidenceOut, status_code=status.HTTP_201_CREATED)
def create_evidence(
    payload: EvidenceCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    item = evidence_service.create_evidence(db, uploaded_by=current_user, **payload.model_dump())
    audit_service.log_action(db, user=current_user, action="EVIDENCE_UPLOADED", resource=f"evidence:{item.evidence_number}")
    return item


@router.get("/{evidence_id}/custody", response_model=list[CustodyEventOut])
def get_custody_chain(evidence_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    item = evidence_service.get_evidence(db, evidence_id)
    if not item:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Evidence not found")
    return item.custody_events


@router.post("/{evidence_id}/custody", response_model=CustodyEventOut, status_code=status.HTTP_201_CREATED)
def add_custody_event(
    evidence_id: int,
    payload: CustodyEventCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    item = evidence_service.get_evidence(db, evidence_id)
    if not item:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Evidence not found")
    event = evidence_service.add_custody_event(db, evidence=item, officer=current_user, **payload.model_dump())
    audit_service.log_action(
        db, user=current_user, action=f"EVIDENCE_{payload.action.upper()}", resource=f"evidence:{item.evidence_number}"
    )
    return event


@router.delete("/{evidence_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_evidence(
    evidence_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    item = evidence_service.get_evidence(db, evidence_id)
    if not item:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Evidence not found")
    evidence_service.delete_evidence(db, item)
    audit_service.log_action(db, user=current_user, action="EVIDENCE_DELETED", resource=f"evidence:{item.evidence_number}")
