"""
Audit log query endpoints.
"""
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.core.dependencies import get_db, require_roles
from app.models.user import User
from app.schemas.audit import AuditLogOut
from app.services import audit_service

router = APIRouter(prefix="/audit-logs", tags=["Audit Logs"])


@router.get("", response_model=list[AuditLogOut])
def list_audit_logs(
    skip: int = 0,
    limit: int = 100,
    user_id: int | None = None,
    action: str | None = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("Administrator", "Auditor", "Supervisor")),
):
    return audit_service.list_logs(db, skip=skip, limit=limit, user_id=user_id, action=action)
