"""
AI Investigator / scanner endpoints — score numbers, calls and media,
and manage the underlying fraud-pattern rule set.
"""
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.core.dependencies import get_current_user, get_db
from app.models.user import User
from app.schemas.scanner import (
    FraudPatternCreate,
    FraudPatternOut,
    ScanRequest,
    ScanResultOut,
)
from app.services import audit_service, scanner_service

router = APIRouter(prefix="/scanner", tags=["AI Scanner"])


@router.post("/analyze", response_model=ScanResultOut)
def analyze(
    payload: ScanRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = scanner_service.score_target(
        db,
        target_type=payload.target_type,
        target_reference=payload.target_reference,
        text_sample=payload.text_sample,
    )
    audit_service.log_action(
        db, user=current_user, action="AI_SCAN",
        resource=f"{payload.target_type}:{payload.target_reference}",
    )
    return result


@router.get("/results", response_model=list[ScanResultOut])
def list_results(skip: int = 0, limit: int = 100, db: Session = Depends(get_db),
                  current_user: User = Depends(get_current_user)):
    return scanner_service.list_scan_results(db, skip=skip, limit=limit)


@router.get("/patterns", response_model=list[FraudPatternOut])
def list_patterns(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    return scanner_service.list_patterns(db)


@router.post("/patterns", response_model=FraudPatternOut, status_code=201)
def create_pattern(payload: FraudPatternCreate, db: Session = Depends(get_db),
                    current_user: User = Depends(get_current_user)):
    pattern = scanner_service.create_pattern(db, **payload.model_dump())
    audit_service.log_action(db, user=current_user, action="FRAUD_PATTERN_CREATED", resource=pattern.name)
    return pattern
