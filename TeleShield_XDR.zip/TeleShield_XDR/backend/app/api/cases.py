"""
Investigation case endpoints.
"""
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.core.dependencies import get_current_user, get_db
from app.models.user import User
from app.schemas.case import CaseCreate, CaseOut, CaseUpdate
from app.services import audit_service, case_service

router = APIRouter(prefix="/cases", tags=["Cases"])


@router.get("", response_model=list[CaseOut])
def list_cases(
    skip: int = 0,
    limit: int = 100,
    status_filter: str | None = None,
    priority: str | None = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return case_service.list_cases(db, skip=skip, limit=limit, status=status_filter, priority=priority)


@router.get("/{case_id}", response_model=CaseOut)
def get_case(case_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    case = case_service.get_case(db, case_id)
    if not case:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Case not found")
    return case


@router.post("", response_model=CaseOut, status_code=status.HTTP_201_CREATED)
def create_case(
    payload: CaseCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    fields = payload.model_dump()
    if fields.get("officer_id") is None:
        fields["officer_id"] = current_user.id
    case = case_service.create_case(db, **fields)
    audit_service.log_action(db, user=current_user, action="CASE_CREATED", resource=f"case:{case.case_number}")
    return case


@router.put("/{case_id}", response_model=CaseOut)
def update_case(
    case_id: int,
    payload: CaseUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    case = case_service.get_case(db, case_id)
    if not case:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Case not found")
    updated = case_service.update_case(db, case, **payload.model_dump(exclude_unset=True))
    audit_service.log_action(db, user=current_user, action="CASE_UPDATED", resource=f"case:{case.case_number}")
    return updated


@router.delete("/{case_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_case(
    case_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    case = case_service.get_case(db, case_id)
    if not case:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Case not found")
    case_service.delete_case(db, case)
    audit_service.log_action(db, user=current_user, action="CASE_DELETED", resource=f"case:{case.case_number}")
