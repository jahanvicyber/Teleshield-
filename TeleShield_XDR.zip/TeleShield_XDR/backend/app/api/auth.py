"""
Authentication endpoints: login, refresh, current user, change password.
"""
from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy.orm import Session

from app.core.dependencies import get_current_user, get_db
from app.core.security import (
    create_access_token,
    create_refresh_token,
    decode_token,
    verify_password,
)
from app.models.user import User
from app.schemas.auth import ChangePasswordRequest, LoginRequest, LoginResponse, RefreshRequest
from app.schemas.token import Token
from app.services import audit_service, user_service

router = APIRouter(prefix="/auth", tags=["Authentication"])


@router.post("/login", response_model=LoginResponse)
def login(payload: LoginRequest, request: Request, db: Session = Depends(get_db)):
    user = user_service.authenticate_user(db, payload.employee_id, payload.password)
    if not user:
        audit_service.log_action(
            db, user=None, action="LOGIN_FAILED", resource=f"employee_id:{payload.employee_id}",
            ip_address=request.client.host if request.client else None, status="Failed",
        )
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid employee ID or password")

    if not user.is_active:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Account is disabled")

    access_token = create_access_token(subject=user.id)
    refresh_token = create_refresh_token(subject=user.id)

    from datetime import datetime, timezone
    user.last_login = datetime.now(timezone.utc)
    db.commit()

    audit_service.log_action(
        db, user=user, action="LOGIN", resource=f"user:{user.employee_id}",
        ip_address=request.client.host if request.client else None,
    )

    return LoginResponse(access_token=access_token, refresh_token=refresh_token, user=user)


@router.post("/refresh", response_model=Token)
def refresh(payload: RefreshRequest, db: Session = Depends(get_db)):
    try:
        decoded = decode_token(payload.refresh_token)
    except ValueError:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid refresh token")

    if decoded.get("type") != "refresh":
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token type")

    user_id = decoded.get("sub")
    user = user_service.get_user(db, int(user_id)) if user_id else None
    if not user or not user.is_active:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="User not found or inactive")

    new_access_token = create_access_token(subject=user.id)
    new_refresh_token = create_refresh_token(subject=user.id)
    return Token(access_token=new_access_token, refresh_token=new_refresh_token)


@router.get("/me", response_model=None)
def me(current_user: User = Depends(get_current_user)):
    from app.schemas.user import UserOut
    return UserOut.model_validate(current_user)


@router.post("/change-password")
def change_password(
    payload: ChangePasswordRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    if not verify_password(payload.current_password, current_user.hashed_password):
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Current password is incorrect")

    user_service.update_user(db, current_user, password=payload.new_password)
    audit_service.log_action(db, user=current_user, action="PASSWORD_CHANGED", resource=f"user:{current_user.employee_id}")
    return {"message": "Password updated successfully"}


@router.post("/logout")
def logout(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    audit_service.log_action(db, user=current_user, action="LOGOUT", resource=f"user:{current_user.employee_id}")
    return {"message": "Logged out"}
