"""
Threat intelligence lookup endpoints.
"""
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.core.dependencies import get_current_user, get_db
from app.models.user import User
from app.schemas.threat_intel import ThreatIntelCreate, ThreatIntelOut
from app.services import audit_service, threat_intel_service

router = APIRouter(prefix="/threat-intelligence", tags=["Threat Intelligence"])


@router.get("", response_model=list[ThreatIntelOut])
def list_entries(skip: int = 0, limit: int = 100, db: Session = Depends(get_db),
                  current_user: User = Depends(get_current_user)):
    return threat_intel_service.list_entries(db, skip=skip, limit=limit)


@router.get("/lookup/{indicator_value}", response_model=ThreatIntelOut | None)
def lookup(indicator_value: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    return threat_intel_service.lookup(db, indicator_value)


@router.post("", response_model=ThreatIntelOut, status_code=201)
def add_or_update(payload: ThreatIntelCreate, db: Session = Depends(get_db),
                   current_user: User = Depends(get_current_user)):
    entry = threat_intel_service.upsert_entry(db, **payload.model_dump())
    audit_service.log_action(
        db, user=current_user, action="THREAT_INTEL_UPDATED", resource=entry.indicator_value
    )
    return entry
