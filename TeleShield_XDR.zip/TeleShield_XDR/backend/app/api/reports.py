"""
Report generation endpoints.
"""
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.core.dependencies import get_current_user, get_db
from app.models.user import User
from app.schemas.report import ReportCreate, ReportOut
from app.services import audit_service, report_service

router = APIRouter(prefix="/reports", tags=["Reports"])


@router.get("", response_model=list[ReportOut])
def list_reports(skip: int = 0, limit: int = 100, db: Session = Depends(get_db),
                  current_user: User = Depends(get_current_user)):
    return report_service.list_reports(db, skip=skip, limit=limit)


@router.get("/{report_id}", response_model=ReportOut)
def get_report(report_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    report = report_service.get_report(db, report_id)
    if not report:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Report not found")
    return report


@router.post("", response_model=ReportOut, status_code=status.HTTP_201_CREATED)
def create_report(payload: ReportCreate, db: Session = Depends(get_db),
                   current_user: User = Depends(get_current_user)):
    report = report_service.create_report(db, generated_by=current_user, **payload.model_dump())
    audit_service.log_action(db, user=current_user, action="REPORT_GENERATED", resource=report.title)
    return report
