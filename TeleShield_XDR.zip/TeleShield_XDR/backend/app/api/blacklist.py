"""
Blacklisted phone number management.
"""
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.core.dependencies import get_current_user, get_db
from app.models.user import User
from app.schemas.number_list import NumberListEntryCreate, NumberListEntryOut
from app.services import audit_service, list_service

router = APIRouter(prefix="/blacklist", tags=["Blacklist"])


@router.get("", response_model=list[NumberListEntryOut])
def list_blacklist(skip: int = 0, limit: int = 100, db: Session = Depends(get_db),
                    current_user: User = Depends(get_current_user)):
    return list_service.list_entries(db, list_type="blacklist", skip=skip, limit=limit)


@router.post("", response_model=NumberListEntryOut, status_code=status.HTTP_201_CREATED)
def add_to_blacklist(payload: NumberListEntryCreate, db: Session = Depends(get_db),
                      current_user: User = Depends(get_current_user)):
    entry = list_service.add_entry(db, list_type="blacklist", added_by=current_user, **payload.model_dump())
    audit_service.log_action(db, user=current_user, action="BLACKLIST_ADD", resource=f"number:{entry.phone_number}")
    return entry


@router.delete("/{entry_id}", status_code=status.HTTP_204_NO_CONTENT)
def remove_from_blacklist(entry_id: int, db: Session = Depends(get_db),
                           current_user: User = Depends(get_current_user)):
    entry = list_service.get_entry(db, entry_id)
    if not entry or entry.list_type != "blacklist":
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Entry not found")
    list_service.remove_entry(db, entry)
    audit_service.log_action(db, user=current_user, action="BLACKLIST_REMOVE", resource=f"number:{entry.phone_number}")
