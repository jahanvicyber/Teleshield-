"""
Dashboard summary & analytics endpoints.
"""
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.core.dependencies import get_current_user, get_db
from app.models.user import User
from app.services import analytics_service

router = APIRouter(prefix="/analytics", tags=["Analytics"])


@router.get("/dashboard")
def dashboard_summary(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    return analytics_service.build_dashboard_summary(db)


@router.get("/carriers")
def carrier_breakdown(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    return analytics_service.carrier_breakdown(db)
