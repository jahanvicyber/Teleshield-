"""
Audit log — records every meaningful action taken in the platform.
"""
from datetime import datetime, timezone

from sqlalchemy import Column, DateTime, ForeignKey, Integer, String
from sqlalchemy.orm import relationship

from app.db.database import Base


class AuditLog(Base):
    __tablename__ = "audit_logs"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    user = relationship("User", foreign_keys=[user_id])

    action = Column(String(150), nullable=False)     # e.g. "LOGIN", "CASE_CREATED"
    resource = Column(String(150), nullable=True)     # e.g. "case:CS-2041"
    ip_address = Column(String(64), nullable=True)
    device = Column(String(255), nullable=True)
    status = Column(String(20), default="Success")    # Success/Failed

    timestamp = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def __repr__(self) -> str:
        return f"<AuditLog {self.action} by user={self.user_id}>"
