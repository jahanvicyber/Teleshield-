"""
Threat intelligence entries — known malicious numbers/domains/hashes.
"""
from datetime import datetime, timezone

from sqlalchemy import Column, DateTime, Float, Integer, String, Text

from app.db.database import Base


class ThreatIntelEntry(Base):
    __tablename__ = "threat_intel_entries"

    id = Column(Integer, primary_key=True, index=True)
    indicator_type = Column(String(20), default="number")  # number/domain/ip/email/hash
    indicator_value = Column(String(255), nullable=False, index=True)

    country = Column(String(80), nullable=True)
    carrier = Column(String(80), nullable=True)
    threat_score = Column(Float, default=0.0)   # 0-100
    report_count = Column(Integer, default=0)
    campaign = Column(String(150), nullable=True)
    mitre_attack_id = Column(String(20), nullable=True)
    notes = Column(Text, nullable=True)

    first_seen = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    last_seen = Column(DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))

    def __repr__(self) -> str:
        return f"<ThreatIntelEntry {self.indicator_value}>"
