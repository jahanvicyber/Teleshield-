"""
Database Models
Import every model here so Base.metadata knows about all tables
before create_all() / Alembic autogenerate runs.
"""
from app.models.role import Role
from app.models.user import User
from app.models.case import Case
from app.models.evidence import Evidence, CustodyEvent
from app.models.call_log import CallLog
from app.models.number_list import NumberListEntry
from app.models.fraud_pattern import FraudPattern, ScanResult
from app.models.threat_intel import ThreatIntelEntry
from app.models.report import Report
from app.models.notification import Notification
from app.models.audit_log import AuditLog

__all__ = [
    "Role",
    "User",
    "Case",
    "Evidence",
    "CustodyEvent",
    "CallLog",
    "NumberListEntry",
    "FraudPattern",
    "ScanResult",
    "ThreatIntelEntry",
    "Report",
    "Notification",
    "AuditLog",
]
