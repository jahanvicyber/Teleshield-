"""
Evidence locker model — media/documents attached to a case with chain of custody.
"""
from datetime import datetime, timezone

from sqlalchemy import Column, DateTime, ForeignKey, Integer, String
from sqlalchemy.orm import relationship

from app.db.database import Base


class Evidence(Base):
    __tablename__ = "evidence"

    id = Column(Integer, primary_key=True, index=True)
    evidence_number = Column(String(50), unique=True, nullable=False, index=True)

    case_id = Column(Integer, ForeignKey("cases.id"), nullable=True)
    case = relationship("Case", back_populates="evidence_items")

    type = Column(String(30), nullable=False)          # Audio / Image / Video / PDF / Document
    file_name = Column(String(255), nullable=False)
    file_path = Column(String(500), nullable=True)
    size_bytes = Column(Integer, default=0)

    sha256_hash = Column(String(128), nullable=True)
    custody_status = Column(String(30), default="Pending")  # Pending / Verified / Transferred / Archived

    uploaded_by_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    uploaded_by = relationship("User", foreign_keys=[uploaded_by_id])

    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    custody_events = relationship("CustodyEvent", back_populates="evidence", cascade="all, delete-orphan")

    def __repr__(self) -> str:
        return f"<Evidence {self.evidence_number}>"


class CustodyEvent(Base):
    """A single chain-of-custody entry for an evidence item."""

    __tablename__ = "custody_events"

    id = Column(Integer, primary_key=True, index=True)
    evidence_id = Column(Integer, ForeignKey("evidence.id"), nullable=False)
    evidence = relationship("Evidence", back_populates="custody_events")

    action = Column(String(30), nullable=False)  # Uploaded/Verified/Assigned/Reviewed/Transferred/Archived
    officer_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    officer = relationship("User", foreign_keys=[officer_id])
    location = Column(String(255), nullable=True)
    digital_signature = Column(String(255), nullable=True)
    timestamp = Column(DateTime, default=lambda: datetime.now(timezone.utc))
