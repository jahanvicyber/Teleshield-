"""
In-app notifications for users.
"""
from datetime import datetime, timezone

from sqlalchemy import Boolean, Column, DateTime, ForeignKey, Integer, String, Text
from sqlalchemy.orm import relationship

from app.db.database import Base


class Notification(Base):
    __tablename__ = "notifications"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)  # null = broadcast to all
    user = relationship("User", foreign_keys=[user_id])

    title = Column(String(255), nullable=False)
    body = Column(Text, nullable=True)
    tone = Column(String(20), default="primary")  # primary/success/warning/danger
    category = Column(String(50), default="system")  # analysis/evidence/case/alert/storage/system

    is_read = Column(Boolean, default=False)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def __repr__(self) -> str:
        return f"<Notification {self.title}>"
