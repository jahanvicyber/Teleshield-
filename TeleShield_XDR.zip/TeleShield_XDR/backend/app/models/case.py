"""
Investigation case model.
"""
from datetime import datetime, timezone

from sqlalchemy import Column, DateTime, ForeignKey, Integer, String, Text
from sqlalchemy.orm import relationship

from app.db.database import Base


class Case(Base):
    __tablename__ = "cases"

    id = Column(Integer, primary_key=True, index=True)
    case_number = Column(String(50), unique=True, nullable=False, index=True)
    title = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    crime_category = Column(String(150), nullable=True)
    location = Column(String(255), nullable=True)

    priority = Column(String(20), default="Medium", nullable=False)   # Low/Medium/High/Critical
    status = Column(String(30), default="Investigating", nullable=False)
    progress = Column(Integer, default=0, nullable=False)  # 0-100

    officer_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    officer = relationship("User", foreign_keys=[officer_id])

    due_date = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))

    evidence_items = relationship("Evidence", back_populates="case", cascade="all, delete-orphan")

    def __repr__(self) -> str:
        return f"<Case {self.case_number}>"
