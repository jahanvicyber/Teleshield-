"""
Generated forensic / court / executive reports.
"""
from datetime import datetime, timezone

from sqlalchemy import Column, DateTime, ForeignKey, Integer, String
from sqlalchemy.orm import relationship

from app.db.database import Base


class Report(Base):
    __tablename__ = "reports"

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String(255), nullable=False)
    report_type = Column(String(50), default="Technical")  # Forensic/Court/Executive/Technical/Chain-of-Custody
    file_format = Column(String(10), default="PDF")         # PDF/DOCX

    case_id = Column(Integer, ForeignKey("cases.id"), nullable=True)
    case = relationship("Case", foreign_keys=[case_id])

    generated_by_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    generated_by = relationship("User", foreign_keys=[generated_by_id])

    file_path = Column(String(500), nullable=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def __repr__(self) -> str:
        return f"<Report {self.title}>"
