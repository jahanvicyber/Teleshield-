"""
Fraud pattern model — rule/heuristic definitions used by the AI scanner
to score numbers, calls and media (scam category signatures, weightings).
"""
from datetime import datetime, timezone

from sqlalchemy import Boolean, Column, DateTime, Float, ForeignKey, Integer, String, Text
from sqlalchemy.orm import relationship

from app.db.database import Base


class FraudPattern(Base):
    __tablename__ = "fraud_patterns"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(150), nullable=False)
    category = Column(String(80), nullable=False)   # KYC Fraud / OTP Scam / Loan Bait / Job Offer / Impersonation
    description = Column(Text, nullable=True)
    keywords = Column(Text, nullable=True)           # comma separated trigger keywords
    weight = Column(Float, default=10.0)              # contribution to risk score
    is_active = Column(Boolean, default=True)

    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    scan_results = relationship("ScanResult", back_populates="matched_pattern")

    def __repr__(self) -> str:
        return f"<FraudPattern {self.name}>"


class ScanResult(Base):
    """Result of running the AI scanner against a number/call/media item."""

    __tablename__ = "scan_results"

    id = Column(Integer, primary_key=True, index=True)
    target_type = Column(String(20), nullable=False)   # number / call / image / video / audio
    target_reference = Column(String(255), nullable=False)

    ai_score = Column(Float, default=0.0)               # 0-100
    verdict = Column(String(20), default="Low")          # Low/Medium/High/Critical
    matched_pattern_id = Column(Integer, ForeignKey("fraud_patterns.id"), nullable=True)
    matched_pattern = relationship("FraudPattern", back_populates="scan_results")

    details = Column(Text, nullable=True)  # JSON-encoded breakdown of the analysis

    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def __repr__(self) -> str:
        return f"<ScanResult {self.target_type}:{self.target_reference} -> {self.verdict}>"
