"""
Blacklist / Whitelist number entries.
"""
from datetime import datetime, timezone

from sqlalchemy import Column, DateTime, ForeignKey, Integer, String, Text
from sqlalchemy.orm import relationship

from app.db.database import Base


class NumberListEntry(Base):
    __tablename__ = "number_list_entries"

    id = Column(Integer, primary_key=True, index=True)
    phone_number = Column(String(30), nullable=False, index=True)
    list_type = Column(String(10), nullable=False, index=True)  # "blacklist" | "whitelist"
    reason = Column(Text, nullable=True)

    added_by_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    added_by = relationship("User", foreign_keys=[added_by_id])

    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def __repr__(self) -> str:
        return f"<NumberListEntry {self.list_type}:{self.phone_number}>"
