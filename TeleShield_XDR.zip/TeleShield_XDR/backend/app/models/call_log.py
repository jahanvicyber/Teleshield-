"""
Call log model — telecom call records analysed by the AI scam engine.
"""
from datetime import datetime, timezone

from sqlalchemy import Column, DateTime, Float, ForeignKey, Integer, String
from sqlalchemy.orm import relationship

from app.db.database import Base


class CallLog(Base):
    __tablename__ = "call_logs"

    id = Column(Integer, primary_key=True, index=True)
    call_reference = Column(String(50), unique=True, nullable=False, index=True)

    phone_number = Column(String(30), nullable=False, index=True)
    country = Column(String(80), nullable=True)
    carrier = Column(String(80), nullable=True)
    duration_seconds = Column(Integer, default=0)

    risk_score = Column(Float, default=0.0)          # 0-100
    risk_level = Column(String(20), default="Low")   # Low/Medium/High/Critical
    category = Column(String(80), nullable=True)     # KYC Fraud / OTP Scam / Loan Bait ...
    status = Column(String(30), default="Analysing")  # Analysing/Assigned/Escalated/Evidence/Closed

    officer_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    officer = relationship("User", foreign_keys=[officer_id])

    case_id = Column(Integer, ForeignKey("cases.id"), nullable=True)

    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def __repr__(self) -> str:
        return f"<CallLog {self.call_reference} {self.phone_number}>"
