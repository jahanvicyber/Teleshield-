from functools import lru_cache
from pathlib import Path

from dotenv import load_dotenv
from pydantic_settings import BaseSettings

# backend directory
BASE_DIR = Path(__file__).resolve().parent.parent.parent

# Load .env
load_dotenv(BASE_DIR / ".env")


class Settings(BaseSettings):
    PROJECT_NAME: str = "TeleShield XDR"
    PROJECT_VERSION: str = "1.0.0"

    API_PREFIX: str = "/api"

    SECRET_KEY: str
    ALGORITHM: str
    ACCESS_TOKEN_EXPIRE_MINUTES: int

    DATABASE_URL: str

    class Config:
        env_file = BASE_DIR / ".env"
        case_sensitive = True


@lru_cache
def get_settings():
    return Settings()


settings = get_settings()