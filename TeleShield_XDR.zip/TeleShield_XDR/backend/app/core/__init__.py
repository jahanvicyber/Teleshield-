"""
Core Configuration
"""