from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api import (
    audit,
    auth,
    blacklist,
    call_logs,
    cases,
    evidence,
    notifications,
    reports,
    scanner,
    threat_intelligence,
    users,
    whitelist,
)
from app.api import analytics as analytics_router
from app.core.config import settings
from app.core.logging import setup_logging
from app.db.init_db import init_db

setup_logging()

app = FastAPI(
    title=settings.PROJECT_NAME,
    version=settings.PROJECT_VERSION,
    description="TeleShield XDR Backend API",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Later replace with your React URL
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def on_startup() -> None:
    # Creates tables + seeds default roles / admin user / fraud patterns
    # on first boot. Safe to call on every startup — it is idempotent.
    init_db()


api_prefix = settings.API_PREFIX

app.include_router(auth.router, prefix=api_prefix)
app.include_router(users.router, prefix=api_prefix)
app.include_router(audit.router, prefix=api_prefix)
app.include_router(cases.router, prefix=api_prefix)
app.include_router(evidence.router, prefix=api_prefix)
app.include_router(call_logs.router, prefix=api_prefix)
app.include_router(blacklist.router, prefix=api_prefix)
app.include_router(whitelist.router, prefix=api_prefix)
app.include_router(scanner.router, prefix=api_prefix)
app.include_router(threat_intelligence.router, prefix=api_prefix)
app.include_router(reports.router, prefix=api_prefix)
app.include_router(notifications.router, prefix=api_prefix)
app.include_router(analytics_router.router, prefix=api_prefix)


@app.get("/")
def root():
    return {
        "application": settings.PROJECT_NAME,
        "version": settings.PROJECT_VERSION,
        "status": "Running",
    }


@app.get("/health")
def health():
    return {
        "status": "healthy",
        "database": "configured",
    }


@app.get(api_prefix)
def api_root():
    return {
        "message": "TeleShield XDR API is working",
        "docs": "/docs",
    }
