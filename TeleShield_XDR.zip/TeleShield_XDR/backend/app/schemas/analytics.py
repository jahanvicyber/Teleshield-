from pydantic import BaseModel


class KpiItem(BaseModel):
    key: str
    label: str
    value: float
    delta: float | None = None
    suffix: str | None = None
    tone: str | None = None


class TrendPoint(BaseModel):
    label: str
    threats: int
    blocked: int


class CategoryBreakdown(BaseModel):
    name: str
    value: float


class DashboardSummary(BaseModel):
    kpis: list[KpiItem]
    daily_trend: list[TrendPoint]
    scam_categories: list[CategoryBreakdown]
    risk_distribution: list[CategoryBreakdown]
