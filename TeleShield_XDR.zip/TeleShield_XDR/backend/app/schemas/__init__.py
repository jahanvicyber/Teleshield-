"""
Pydantic Schemas
""" 