from datetime import datetime

from pydantic import BaseModel, ConfigDict


class ScanRequest(BaseModel):
    target_type: str  # number / call / image / video / audio
    target_reference: str
    text_sample: str | None = None  # e.g. call transcript / SMS text used for keyword matching


class ScanResultOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    target_type: str
    target_reference: str
    ai_score: float
    verdict: str
    matched_pattern_id: int | None = None
    details: str | None = None
    created_at: datetime


class FraudPatternBase(BaseModel):
    name: str
    category: str
    description: str | None = None
    keywords: str | None = None
    weight: float = 10.0
    is_active: bool = True


class FraudPatternCreate(FraudPatternBase):
    pass


class FraudPatternOut(FraudPatternBase):
    model_config = ConfigDict(from_attributes=True)
    id: int
    created_at: datetime
