from datetime import datetime

from pydantic import BaseModel, ConfigDict


class EvidenceBase(BaseModel):
    type: str
    file_name: str
    case_id: int | None = None


class EvidenceCreate(EvidenceBase):
    size_bytes: int = 0
    sha256_hash: str | None = None


class EvidenceOut(EvidenceBase):
    model_config = ConfigDict(from_attributes=True)
    id: int
    evidence_number: str
    size_bytes: int
    sha256_hash: str | None = None
    custody_status: str
    uploaded_by_id: int | None = None
    created_at: datetime


class CustodyEventOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    evidence_id: int
    action: str
    officer_id: int | None = None
    location: str | None = None
    digital_signature: str | None = None
    timestamp: datetime


class CustodyEventCreate(BaseModel):
    action: str
    location: str | None = None
    digital_signature: str | None = None
