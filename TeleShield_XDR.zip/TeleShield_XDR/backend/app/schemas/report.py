from datetime import datetime

from pydantic import BaseModel, ConfigDict


class ReportCreate(BaseModel):
    title: str
    report_type: str = "Technical"
    file_format: str = "PDF"
    case_id: int | None = None


class ReportOut(ReportCreate):
    model_config = ConfigDict(from_attributes=True)
    id: int
    generated_by_id: int | None = None
    file_path: str | None = None
    created_at: datetime
