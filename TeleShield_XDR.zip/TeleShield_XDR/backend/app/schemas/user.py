from datetime import datetime

from pydantic import BaseModel, ConfigDict, EmailStr


class RoleOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    name: str
    description: str | None = None


class UserBase(BaseModel):
    employee_id: str
    full_name: str
    email: EmailStr
    agency: str | None = None
    department: str | None = None


class UserCreate(UserBase):
    password: str
    role_id: int | None = None


class UserUpdate(BaseModel):
    full_name: str | None = None
    email: EmailStr | None = None
    agency: str | None = None
    department: str | None = None
    role_id: int | None = None
    is_active: bool | None = None
    password: str | None = None


class UserOut(UserBase):
    model_config = ConfigDict(from_attributes=True)
    id: int
    is_active: bool
    role: RoleOut | None = None
    created_at: datetime
    last_login: datetime | None = None
