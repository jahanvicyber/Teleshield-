from datetime import datetime

from pydantic import BaseModel, ConfigDict


class AuditLogOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    user_id: int | None = None
    action: str
    resource: str | None = None
    ip_address: str | None = None
    device: str | None = None
    status: str
    timestamp: datetime
