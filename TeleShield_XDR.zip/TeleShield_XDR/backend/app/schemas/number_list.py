from datetime import datetime

from pydantic import BaseModel, ConfigDict


class NumberListEntryCreate(BaseModel):
    phone_number: str
    reason: str | None = None


class NumberListEntryOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    phone_number: str
    list_type: str
    reason: str | None = None
    added_by_id: int | None = None
    created_at: datetime
