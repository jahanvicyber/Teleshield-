from pydantic import BaseModel

from app.schemas.user import UserOut


class LoginRequest(BaseModel):
    employee_id: str
    password: str
    agency: str | None = None
    otp: str | None = None


class LoginResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    user: UserOut


class RefreshRequest(BaseModel):
    refresh_token: str


class ChangePasswordRequest(BaseModel):
    current_password: str
    new_password: str
