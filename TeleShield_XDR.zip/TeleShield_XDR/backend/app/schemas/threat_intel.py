from datetime import datetime

from pydantic import BaseModel, ConfigDict


class ThreatIntelCreate(BaseModel):
    indicator_type: str = "number"
    indicator_value: str
    country: str | None = None
    carrier: str | None = None
    threat_score: float = 0.0
    campaign: str | None = None
    mitre_attack_id: str | None = None
    notes: str | None = None


class ThreatIntelOut(ThreatIntelCreate):
    model_config = ConfigDict(from_attributes=True)
    id: int
    report_count: int
    first_seen: datetime
    last_seen: datetime
