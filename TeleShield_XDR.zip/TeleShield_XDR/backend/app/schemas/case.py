from datetime import datetime

from pydantic import BaseModel, ConfigDict


class CaseBase(BaseModel):
    title: str
    description: str | None = None
    crime_category: str | None = None
    location: str | None = None
    priority: str = "Medium"
    status: str = "Investigating"
    due_date: datetime | None = None


class CaseCreate(CaseBase):
    officer_id: int | None = None


class CaseUpdate(BaseModel):
    title: str | None = None
    description: str | None = None
    crime_category: str | None = None
    location: str | None = None
    priority: str | None = None
    status: str | None = None
    progress: int | None = None
    officer_id: int | None = None
    due_date: datetime | None = None


class CaseOut(CaseBase):
    model_config = ConfigDict(from_attributes=True)
    id: int
    case_number: str
    progress: int
    officer_id: int | None = None
    created_at: datetime
    updated_at: datetime | None = None
