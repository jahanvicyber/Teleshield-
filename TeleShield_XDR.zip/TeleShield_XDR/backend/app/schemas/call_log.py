from datetime import datetime

from pydantic import BaseModel, ConfigDict


class CallLogBase(BaseModel):
    phone_number: str
    country: str | None = None
    carrier: str | None = None
    duration_seconds: int = 0


class CallLogCreate(CallLogBase):
    pass


class CallLogOut(CallLogBase):
    model_config = ConfigDict(from_attributes=True)
    id: int
    call_reference: str
    risk_score: float
    risk_level: str
    category: str | None = None
    status: str
    officer_id: int | None = None
    case_id: int | None = None
    created_at: datetime
