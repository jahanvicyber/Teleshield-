from datetime import datetime

from pydantic import BaseModel, ConfigDict


class NotificationCreate(BaseModel):
    user_id: int | None = None
    title: str
    body: str | None = None
    tone: str = "primary"
    category: str = "system"


class NotificationOut(NotificationCreate):
    model_config = ConfigDict(from_attributes=True)
    id: int
    is_read: bool
    created_at: datetime
