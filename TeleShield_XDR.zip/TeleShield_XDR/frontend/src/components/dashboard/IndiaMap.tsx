import { motion } from "framer-motion";

const states = [
  { name: "Maharashtra", x: 260, y: 340, count: 412, r: 22 },
  { name: "Delhi NCR", x: 300, y: 200, count: 388, r: 20 },
  { name: "Karnataka", x: 290, y: 430, count: 274, r: 18 },
  { name: "Tamil Nadu", x: 330, y: 500, count: 231, r: 16 },
  { name: "West Bengal", x: 470, y: 300, count: 198, r: 15 },
  { name: "Gujarat", x: 180, y: 300, count: 176, r: 14 },
  { name: "Telangana", x: 320, y: 400, count: 152, r: 13 },
  { name: "Kerala", x: 290, y: 520, count: 138, r: 12 },
  { name: "UP", x: 340, y: 230, count: 122, r: 12 },
  { name: "Punjab", x: 250, y: 160, count: 96, r: 10 },
];

export function IndiaMap() {
  return (
    <div className="glass-card relative overflow-hidden rounded-2xl p-5">
      <div className="mb-3 flex items-center justify-between">
        <div>
          <h3 className="text-sm font-semibold">Threat Hotspots · India</h3>
          <p className="text-[11px] text-muted-foreground">
            State-wise incident density (last 24h)
          </p>
        </div>
        <div className="flex items-center gap-2 text-[10px] text-muted-foreground">
          <span className="flex items-center gap-1">
            <span className="h-2 w-2 rounded-full bg-primary" /> Low
          </span>
          <span className="flex items-center gap-1">
            <span className="h-2 w-2 rounded-full bg-warning" /> Med
          </span>
          <span className="flex items-center gap-1">
            <span className="h-2 w-2 rounded-full bg-destructive" /> High
          </span>
        </div>
      </div>
      <div className="relative h-[380px] w-full grid-bg rounded-xl border border-border/60 bg-background/40">
        <svg viewBox="0 0 640 620" className="h-full w-full">
          {/* Stylised India outline (approximate silhouette) */}
          <path
            d="M230 90 L300 80 L360 110 L420 130 L470 170 L500 220 L520 280 L500 330 L470 360 L490 400 L470 440 L440 470 L400 500 L360 540 L320 560 L290 540 L280 500 L250 470 L220 430 L200 380 L180 330 L170 280 L160 230 L180 170 L210 120 Z"
            fill="oklch(0.63 0.19 258 / 0.06)"
            stroke="oklch(0.63 0.19 258 / 0.4)"
            strokeWidth="1.2"
          />
          {states.map((s, i) => {
            const color =
              s.count > 300
                ? "var(--destructive)"
                : s.count > 180
                  ? "var(--warning)"
                  : "var(--primary)";
            return (
              <g key={s.name}>
                <motion.circle
                  cx={s.x}
                  cy={s.y}
                  r={s.r}
                  fill={color}
                  fillOpacity={0.18}
                  initial={{ scale: 0 }}
                  animate={{ scale: [1, 1.15, 1] }}
                  transition={{
                    delay: i * 0.08,
                    duration: 2.2,
                    repeat: Infinity,
                  }}
                />
                <circle cx={s.x} cy={s.y} r={4} fill={color} />
                <text
                  x={s.x + 10}
                  y={s.y + 4}
                  fill="white"
                  fontSize="10"
                  opacity={0.8}
                >
                  {s.name} · {s.count}
                </text>
              </g>
            );
          })}
        </svg>
      </div>
    </div>
  );
}
