import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import {
  dailyTrend,
  scamCategories,
  riskDistribution,
  carriers,
} from "@/lib/mock-data";

const tooltip = {
  contentStyle: {
    background: "oklch(0.19 0.03 265 / 0.95)",
    border: "1px solid oklch(1 0 0 / 0.08)",
    borderRadius: 10,
    fontSize: 12,
    color: "white",
  },
  labelStyle: { color: "oklch(0.72 0.03 260)", fontSize: 11 },
  cursor: { fill: "oklch(1 0 0 / 0.04)" },
} as const;

export function ThreatTrendChart() {
  return (
    <div className="glass-card rounded-2xl p-5">
      <div className="mb-4 flex items-center justify-between">
        <div>
          <h3 className="text-sm font-semibold">Daily Threat Trend</h3>
          <p className="text-xs text-muted-foreground">
            Detected vs. blocked · last 14 days
          </p>
        </div>
        <div className="flex items-center gap-3 text-[11px] text-muted-foreground">
          <span className="flex items-center gap-1.5">
            <span className="h-2 w-2 rounded-full bg-primary" /> Detected
          </span>
          <span className="flex items-center gap-1.5">
            <span className="h-2 w-2 rounded-full bg-success" /> Blocked
          </span>
        </div>
      </div>
      <ResponsiveContainer width="100%" height={260}>
        <AreaChart data={dailyTrend} margin={{ left: -10, right: 8, top: 6 }}>
          <defs>
            <linearGradient id="p1" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="var(--primary)" stopOpacity={0.5} />
              <stop offset="100%" stopColor="var(--primary)" stopOpacity={0} />
            </linearGradient>
            <linearGradient id="p2" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="var(--success)" stopOpacity={0.4} />
              <stop offset="100%" stopColor="var(--success)" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid stroke="oklch(1 0 0 / 0.06)" vertical={false} />
          <XAxis
            dataKey="day"
            tick={{ fill: "oklch(0.72 0.03 260)", fontSize: 11 }}
            axisLine={false}
            tickLine={false}
          />
          <YAxis
            tick={{ fill: "oklch(0.72 0.03 260)", fontSize: 11 }}
            axisLine={false}
            tickLine={false}
          />
          <Tooltip {...tooltip} />
          <Area
            dataKey="threats"
            stroke="var(--primary)"
            strokeWidth={2}
            fill="url(#p1)"
          />
          <Area
            dataKey="blocked"
            stroke="var(--success)"
            strokeWidth={2}
            fill="url(#p2)"
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}

export function RiskDonut() {
  const total = riskDistribution.reduce((s, r) => s + r.value, 0);
  return (
    <div className="glass-card rounded-2xl p-5">
      <div className="mb-2">
        <h3 className="text-sm font-semibold">Risk Distribution</h3>
        <p className="text-xs text-muted-foreground">
          All-time classification split
        </p>
      </div>
      <div className="relative">
        <ResponsiveContainer width="100%" height={220}>
          <PieChart>
            <Pie
              data={riskDistribution}
              dataKey="value"
              innerRadius={60}
              outerRadius={90}
              paddingAngle={3}
              stroke="none"
            >
              {riskDistribution.map((r) => (
                <Cell key={r.name} fill={r.color} />
              ))}
            </Pie>
            <Tooltip {...tooltip} />
          </PieChart>
        </ResponsiveContainer>
        <div className="pointer-events-none absolute inset-0 grid place-items-center">
          <div className="text-center">
            <div className="text-2xl font-bold tabular-nums">
              {(total / 1000).toFixed(1)}k
            </div>
            <div className="text-[10px] uppercase tracking-widest text-muted-foreground">
              Total
            </div>
          </div>
        </div>
      </div>
      <div className="mt-2 grid grid-cols-2 gap-2 text-xs">
        {riskDistribution.map((r) => (
          <div
            key={r.name}
            className="flex items-center justify-between rounded-md bg-muted/30 px-2 py-1.5"
          >
            <span className="flex items-center gap-2">
              <span
                className="h-2 w-2 rounded-full"
                style={{ background: r.color }}
              />
              {r.name}
            </span>
            <span className="tabular-nums text-muted-foreground">
              {r.value.toLocaleString()}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

export function ScamCategoriesChart() {
  return (
    <div className="glass-card rounded-2xl p-5">
      <div className="mb-4">
        <h3 className="text-sm font-semibold">Top Scam Categories</h3>
        <p className="text-xs text-muted-foreground">
          Share of flagged calls this month
        </p>
      </div>
      <ResponsiveContainer width="100%" height={220}>
        <BarChart
          data={scamCategories}
          layout="vertical"
          margin={{ left: 8, right: 8 }}
        >
          <CartesianGrid stroke="oklch(1 0 0 / 0.05)" horizontal={false} />
          <XAxis
            type="number"
            tick={{ fill: "oklch(0.72 0.03 260)", fontSize: 11 }}
            axisLine={false}
            tickLine={false}
          />
          <YAxis
            type="category"
            dataKey="name"
            width={90}
            tick={{ fill: "oklch(0.85 0.02 250)", fontSize: 11 }}
            axisLine={false}
            tickLine={false}
          />
          <Tooltip {...tooltip} />
          <Bar dataKey="value" fill="var(--primary)" radius={[0, 6, 6, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

export function CarrierChart() {
  return (
    <div className="glass-card rounded-2xl p-5">
      <div className="mb-4 flex items-center justify-between">
        <div>
          <h3 className="text-sm font-semibold">Carrier Analysis</h3>
          <p className="text-xs text-muted-foreground">
            Flagged originations by carrier
          </p>
        </div>
      </div>
      <ResponsiveContainer width="100%" height={220}>
        <BarChart data={carriers} margin={{ left: -12, right: 8 }}>
          <CartesianGrid stroke="oklch(1 0 0 / 0.05)" vertical={false} />
          <XAxis
            dataKey="name"
            tick={{ fill: "oklch(0.72 0.03 260)", fontSize: 11 }}
            axisLine={false}
            tickLine={false}
          />
          <YAxis
            tick={{ fill: "oklch(0.72 0.03 260)", fontSize: 11 }}
            axisLine={false}
            tickLine={false}
          />
          <Tooltip {...tooltip} />
          <Bar dataKey="flagged" radius={[6, 6, 0, 0]}>
            {carriers.map((_, i) => (
              <Cell key={i} fill={`oklch(0.63 0.19 ${240 + i * 15})`} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
