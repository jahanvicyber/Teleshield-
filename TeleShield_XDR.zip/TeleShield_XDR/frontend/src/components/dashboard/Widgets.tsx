import { motion } from "framer-motion";
import { liveFeed, cases, evidence, threatIntel } from "@/lib/mock-data";
import {
  Radio,
  FileAudio,
  FileImage,
  FileText,
  Fingerprint,
  Globe2,
} from "lucide-react";
import { cn } from "@/lib/utils";

const riskBadge = (r: string) =>
  r === "Critical"
    ? "bg-destructive/15 text-destructive border-destructive/30"
    : r === "High"
      ? "bg-warning/15 text-warning border-warning/30"
      : r === "Medium"
        ? "bg-primary/15 text-primary border-primary/30"
        : "bg-success/15 text-success border-success/30";

export function LiveFeed() {
  return (
    <div className="glass-card rounded-2xl">
      <div className="flex items-center justify-between border-b border-border/60 px-5 py-4">
        <div className="flex items-center gap-2">
          <span className="relative flex h-2 w-2">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-destructive opacity-75" />
            <span className="relative inline-flex h-2 w-2 rounded-full bg-destructive" />
          </span>
          <h3 className="text-sm font-semibold">Live Investigations</h3>
          <span className="ml-1 rounded-full bg-muted/60 px-2 py-0.5 text-[10px] text-muted-foreground">
            real-time
          </span>
        </div>
        <Radio className="h-4 w-4 text-muted-foreground" />
      </div>
      <div className="max-h-[420px] overflow-y-auto p-2">
        {liveFeed.map((f, i) => (
          <motion.div
            key={f.id}
            initial={{ opacity: 0, x: -8 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.04 }}
            className="grid grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-3 rounded-xl px-3 py-2.5 hover:bg-muted/30"
          >
            <div className="grid h-9 w-9 place-items-center rounded-lg bg-primary/10 text-primary font-mono text-[10px]">
              {f.id.slice(-3)}
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span className="truncate font-mono text-sm">{f.number}</span>
                <span
                  className={cn(
                    "rounded-full border px-1.5 py-0.5 text-[10px] font-semibold",
                    riskBadge(f.risk),
                  )}
                >
                  {f.risk}
                </span>
              </div>
              <div className="mt-0.5 truncate text-[11px] text-muted-foreground">
                {f.officer} ·{" "}
                <span className="text-foreground/80">{f.status}</span>
              </div>
            </div>
            <div className="text-right text-[10px] text-muted-foreground tabular-nums">
              {f.time}
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

export function CasesWidget() {
  return (
    <div className="glass-card rounded-2xl">
      <div className="flex items-center justify-between border-b border-border/60 px-5 py-4">
        <h3 className="text-sm font-semibold">Latest Cases</h3>
        <a className="text-xs text-primary hover:underline" href="/cases">
          View all →
        </a>
      </div>
      <div className="divide-y divide-border/50">
        {cases.map((c) => (
          <div
            key={c.id}
            className="grid grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-4 px-5 py-3.5"
          >
            <div className="grid h-10 w-10 place-items-center rounded-lg bg-accent/40 font-mono text-[10px] text-foreground/80">
              {c.id.slice(-3)}
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span
                  className={cn(
                    "rounded-full border px-1.5 py-0.5 text-[10px] font-semibold",
                    riskBadge(c.priority),
                  )}
                >
                  {c.priority}
                </span>
                <span className="truncate text-sm font-medium">{c.title}</span>
              </div>
              <div className="mt-1 flex items-center gap-2 text-[11px] text-muted-foreground">
                <span>{c.officer}</span>
                <span>·</span>
                <span>{c.status}</span>
                <span>·</span>
                <span>Due {c.due}</span>
              </div>
              <div className="mt-1.5 h-1 overflow-hidden rounded-full bg-muted/50">
                <div
                  className="h-full bg-gradient-to-r from-primary to-[oklch(0.68_0.16_300)]"
                  style={{ width: `${c.progress}%` }}
                />
              </div>
            </div>
            <div className="text-right text-xs font-bold tabular-nums text-foreground/90">
              {c.progress}%
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

const evIcon = (t: string) =>
  t === "Audio" ? FileAudio : t === "Image" ? FileImage : FileText;

export function EvidenceWidget() {
  return (
    <div className="glass-card rounded-2xl">
      <div className="flex items-center justify-between border-b border-border/60 px-5 py-4">
        <h3 className="text-sm font-semibold">Recent Evidence</h3>
        <a className="text-xs text-primary hover:underline" href="/evidence">
          Browse →
        </a>
      </div>
      <div className="divide-y divide-border/50">
        {evidence.map((e) => {
          const Icon = evIcon(e.type);
          return (
            <div
              key={e.id}
              className="grid grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-3 px-5 py-3"
            >
              <div
                className={cn(
                  "grid h-9 w-9 place-items-center rounded-lg",
                  e.type === "Audio" && "bg-primary/15 text-primary",
                  e.type === "Image" && "bg-success/15 text-success",
                  e.type === "PDF" && "bg-warning/15 text-warning",
                )}
              >
                <Icon className="h-4 w-4" />
              </div>
              <div className="min-w-0">
                <div className="truncate text-sm font-medium">{e.name}</div>
                <div className="mt-0.5 flex items-center gap-1.5 text-[11px] text-muted-foreground">
                  <Fingerprint className="h-3 w-3" />
                  <span className="font-mono">{e.hash}</span>
                  <span>·</span>
                  <span>{e.size}</span>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span
                  className={cn(
                    "rounded-full border px-2 py-0.5 text-[10px] font-semibold",
                    e.custody === "Verified"
                      ? "border-success/30 bg-success/10 text-success"
                      : "border-warning/30 bg-warning/10 text-warning",
                  )}
                >
                  {e.custody}
                </span>
                <span className="w-8 text-right text-[10px] text-muted-foreground">
                  {e.time}
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export function ThreatIntelWidget() {
  return (
    <div className="glass-card rounded-2xl">
      <div className="flex items-center justify-between border-b border-border/60 px-5 py-4">
        <div>
          <h3 className="text-sm font-semibold">Threat Intelligence</h3>
          <p className="text-[11px] text-muted-foreground">
            Known scam numbers · updated 2m ago
          </p>
        </div>
        <Globe2 className="h-4 w-4 text-muted-foreground" />
      </div>
      <div className="divide-y divide-border/50">
        {threatIntel.map((t) => (
          <div
            key={t.number}
            className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 px-5 py-3"
          >
            <div className="min-w-0">
              <div className="truncate font-mono text-sm">{t.number}</div>
              <div className="mt-0.5 text-[11px] text-muted-foreground">
                {t.country} · {t.carrier} · {t.reports} reports
              </div>
            </div>
            <div className="flex items-center gap-2">
              <div className="h-1.5 w-16 overflow-hidden rounded-full bg-muted/50">
                <div
                  className="h-full bg-gradient-to-r from-warning to-destructive"
                  style={{ width: `${t.score}%` }}
                />
              </div>
              <span className="w-8 text-right text-sm font-bold tabular-nums text-destructive">
                {t.score}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
