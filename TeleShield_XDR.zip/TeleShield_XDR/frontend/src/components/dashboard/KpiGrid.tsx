import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { AreaChart, Area, ResponsiveContainer } from "recharts";
import {
  Phone,
  AlertTriangle,
  ShieldAlert,
  Folder,
  FileLock2,
  Sparkles,
  Users,
  FileText,
  ArrowUpRight,
  ArrowDownRight,
} from "lucide-react";
import { kpis } from "@/lib/mock-data";
import { cn } from "@/lib/utils";

const iconMap = {
  Phone,
  AlertTriangle,
  ShieldAlert,
  Folder,
  FileLock2,
  Sparkles,
  Users,
  FileText,
};

function useCountUp(target: number, duration = 1200) {
  const [v, setV] = useState(0);
  useEffect(() => {
    let raf = 0;
    const start = performance.now();
    const step = (t: number) => {
      const p = Math.min(1, (t - start) / duration);
      setV(target * (1 - Math.pow(1 - p, 3)));
      if (p < 1) raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [target, duration]);
  return v;
}

function Spark({ tone }: { tone: string }) {
  const [data] = useState(() =>
    Array.from({ length: 18 }, (_, i) => ({
      v: 20 + Math.sin(i / 2) * 10 + Math.random() * 12,
    })),
  );
  const color =
    tone === "danger"
      ? "var(--destructive)"
      : tone === "warning"
        ? "var(--warning)"
        : tone === "success"
          ? "var(--success)"
          : "var(--primary)";
  return (
    <ResponsiveContainer width="100%" height={44}>
      <AreaChart data={data} margin={{ top: 2, right: 0, bottom: 0, left: 0 }}>
        <defs>
          <linearGradient id={`g-${tone}`} x1="0" x2="0" y1="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity={0.6} />
            <stop offset="100%" stopColor={color} stopOpacity={0} />
          </linearGradient>
        </defs>
        <Area
          type="monotone"
          dataKey="v"
          stroke={color}
          strokeWidth={2}
          fill={`url(#g-${tone})`}
        />
      </AreaChart>
    </ResponsiveContainer>
  );
}

export function KpiGrid() {
  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
      {kpis.map((k, i) => {
        const Icon = iconMap[k.icon as keyof typeof iconMap];
        const tone = k.tone ?? "primary";
        const positive = k.delta >= 0;
        return (
          <motion.div
            key={k.key}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.04, duration: 0.4 }}
            whileHover={{ y: -3 }}
            className="glass-card group relative overflow-hidden rounded-2xl p-5"
          >
            <div className="absolute -right-6 -top-6 h-24 w-24 rounded-full bg-primary/10 blur-2xl transition-opacity group-hover:opacity-100" />
            <div className="flex items-start justify-between">
              <div
                className={cn(
                  "grid h-10 w-10 place-items-center rounded-xl",
                  tone === "danger" && "bg-destructive/15 text-destructive",
                  tone === "warning" && "bg-warning/15 text-warning",
                  tone === "success" && "bg-success/15 text-success",
                  (tone === "primary" || !k.tone) &&
                    "bg-primary/15 text-primary",
                )}
              >
                <Icon className="h-5 w-5" />
              </div>
              <div
                className={cn(
                  "flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-semibold",
                  positive
                    ? "bg-success/15 text-success"
                    : "bg-destructive/15 text-destructive",
                )}
              >
                {positive ? (
                  <ArrowUpRight className="h-3 w-3" />
                ) : (
                  <ArrowDownRight className="h-3 w-3" />
                )}
                {Math.abs(k.delta)}%
              </div>
            </div>
            <div className="mt-4 text-xs uppercase tracking-wider text-muted-foreground">
              {k.label}
            </div>
            <Counter value={k.value} suffix={k.suffix} />
            <div className="mt-1">
              <Spark tone={tone} />
            </div>
          </motion.div>
        );
      })}
    </div>
  );
}

function Counter({ value, suffix }: { value: number; suffix?: string }) {
  const v = useCountUp(value);
  const formatted =
    value % 1 === 0 ? Math.round(v).toLocaleString() : v.toFixed(1);
  return (
    <div className="mt-1 text-2xl font-bold tracking-tight tabular-nums">
      {formatted}
      {suffix && (
        <span className="ml-0.5 text-base font-semibold text-muted-foreground">
          {suffix}
        </span>
      )}
    </div>
  );
}
