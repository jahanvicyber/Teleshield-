import { motion } from "framer-motion";
import { Brain, TrendingUp, ShieldAlert, Check } from "lucide-react";

const factors = [
  {
    label: "Carrier mismatch (VoIP → India mobile)",
    weight: 28,
    tone: "danger",
  },
  { label: "Repeated spam reports (n=412)", weight: 24, tone: "danger" },
  { label: "Short duration pattern (<12s avg)", weight: 18, tone: "warning" },
  { label: "High call frequency (>60/hr)", weight: 16, tone: "warning" },
  { label: "Location anomaly (Nigeria → +91)", weight: 12, tone: "primary" },
] as const;

export function AiRiskPanel() {
  const score = 96;
  return (
    <div className="glass-card relative overflow-hidden rounded-2xl p-6">
      <div className="absolute -right-10 -top-10 h-56 w-56 rounded-full bg-primary/20 blur-3xl" />
      <div className="absolute -left-16 bottom-0 h-56 w-56 rounded-full bg-[oklch(0.68_0.16_300)]/15 blur-3xl" />

      <div className="relative flex flex-col gap-6 lg:flex-row lg:items-center">
        {/* Left: gauge */}
        <div className="flex items-center gap-5">
          <div className="relative grid h-28 w-28 place-items-center">
            <svg viewBox="0 0 100 100" className="absolute inset-0 -rotate-90">
              <circle
                cx="50"
                cy="50"
                r="42"
                stroke="oklch(1 0 0 / 0.08)"
                strokeWidth="8"
                fill="none"
              />
              <motion.circle
                cx="50"
                cy="50"
                r="42"
                fill="none"
                stroke="url(#riskGrad)"
                strokeWidth="8"
                strokeLinecap="round"
                strokeDasharray={2 * Math.PI * 42}
                initial={{ strokeDashoffset: 2 * Math.PI * 42 }}
                animate={{
                  strokeDashoffset: 2 * Math.PI * 42 * (1 - score / 100),
                }}
                transition={{ duration: 1.4, ease: "easeOut" }}
              />
              <defs>
                <linearGradient id="riskGrad" x1="0" x2="1" y1="0" y2="1">
                  <stop offset="0%" stopColor="var(--destructive)" />
                  <stop offset="100%" stopColor="var(--warning)" />
                </linearGradient>
              </defs>
            </svg>
            <div className="text-center">
              <div className="text-3xl font-bold tabular-nums">{score}</div>
              <div className="text-[10px] uppercase tracking-widest text-muted-foreground">
                Risk
              </div>
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-primary">
              <Brain className="h-4 w-4" /> AI Risk Analysis
            </div>
            <div className="mt-1 text-lg font-semibold">
              Critical threat detected
            </div>
            <div className="mt-1 flex items-center gap-2 text-xs text-muted-foreground">
              <TrendingUp className="h-3.5 w-3.5" />
              Confidence{" "}
              <span className="font-semibold text-foreground">98.4%</span>
              <span>·</span>
              Model{" "}
              <span className="font-mono text-foreground">tsx-guard-v4.2</span>
            </div>
          </div>
        </div>

        {/* Middle: reasoning */}
        <div className="flex-1 rounded-xl border border-border/60 bg-background/40 p-4 text-sm">
          <div className="mb-1 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
            Reasoning
          </div>
          <p className="text-foreground/90">
            Number originates via VoIP gateway in Lagos routed through a Mumbai
            carrier. Pattern matches the
            <span className="font-semibold text-warning">
              {" "}
              "OTP Interception Ring"{" "}
            </span>
            cluster active since 09 Nov. Recommend immediate escalation and
            evidence capture.
          </p>
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <span className="inline-flex items-center gap-1.5 rounded-full bg-destructive/15 px-2.5 py-1 text-[11px] font-semibold text-destructive">
              <ShieldAlert className="h-3.5 w-3.5" /> Threat: Critical
            </span>
            <span className="inline-flex items-center gap-1.5 rounded-full bg-primary/15 px-2.5 py-1 text-[11px] font-semibold text-primary">
              <Check className="h-3.5 w-3.5" /> Action: Escalate to DySP
            </span>
          </div>
        </div>
      </div>

      {/* Explainable AI */}
      <div className="relative mt-6">
        <div className="mb-2 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
          Explainable AI · contributing factors
        </div>
        <div className="space-y-2">
          {factors.map((f, i) => (
            <div
              key={f.label}
              className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-4"
            >
              <div className="min-w-0">
                <div className="mb-1 flex justify-between text-xs">
                  <span className="truncate text-foreground/90">{f.label}</span>
                  <span className="tabular-nums text-muted-foreground">
                    {f.weight}%
                  </span>
                </div>
                <div className="h-1.5 overflow-hidden rounded-full bg-muted/50">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${f.weight * 3}%` }}
                    transition={{ delay: 0.1 + i * 0.08, duration: 0.7 }}
                    className={
                      f.tone === "danger"
                        ? "h-full bg-destructive"
                        : f.tone === "warning"
                          ? "h-full bg-warning"
                          : "h-full bg-primary"
                    }
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
