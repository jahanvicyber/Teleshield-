import { X, AlertTriangle, ShieldCheck, FileText, UserCog } from "lucide-react";
import { notifications } from "@/lib/mock-data";
import { cn } from "@/lib/utils";

const toneMap = {
  danger: { icon: AlertTriangle, ring: "text-destructive bg-destructive/15" },
  primary: { icon: UserCog, ring: "text-primary bg-primary/15" },
  success: { icon: ShieldCheck, ring: "text-success bg-success/15" },
  warning: { icon: FileText, ring: "text-warning bg-warning/15" },
} as const;

export function NotificationPanel({
  open,
  onClose,
}: {
  open: boolean;
  onClose: () => void;
}) {
  return (
    <>
      <div
        className={cn(
          "fixed inset-0 z-40 bg-background/60 backdrop-blur-sm transition-opacity",
          open ? "opacity-100" : "pointer-events-none opacity-0",
        )}
        onClick={onClose}
      />
      <aside
        className={cn(
          "fixed right-0 top-0 z-50 flex h-screen w-full max-w-md flex-col border-l border-border/60 bg-card/95 shadow-2xl backdrop-blur-xl transition-transform duration-300",
          open ? "translate-x-0" : "translate-x-full",
        )}
      >
        <div className="flex h-16 items-center justify-between border-b border-border/60 px-5">
          <div>
            <h3 className="text-sm font-semibold">Live notifications</h3>
            <p className="text-[11px] text-muted-foreground">
              Real-time XDR events
            </p>
          </div>
          <button
            onClick={onClose}
            className="grid h-8 w-8 place-items-center rounded-md hover:bg-muted/60"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
        <div className="flex-1 space-y-2 overflow-y-auto p-4">
          {notifications.concat(notifications).map((n, i) => {
            const T = toneMap[n.tone];
            return (
              <div
                key={i}
                className="glass-card flex items-start gap-3 rounded-xl p-3.5"
              >
                <div
                  className={cn(
                    "grid h-9 w-9 shrink-0 place-items-center rounded-lg",
                    T.ring,
                  )}
                >
                  <T.icon className="h-4 w-4" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-2">
                    <p className="truncate text-sm font-medium">{n.title}</p>
                    <span className="shrink-0 text-[10px] text-muted-foreground">
                      {n.time}
                    </span>
                  </div>
                  <p className="mt-0.5 truncate text-xs text-muted-foreground">
                    {n.body}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </aside>
    </>
  );
}
