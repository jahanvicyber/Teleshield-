import { AppShell } from "@/components/layout/AppShell";
import { Construction, Sparkles } from "lucide-react";
import type { LucideIcon } from "lucide-react";

export function PagePlaceholder({
  title,
  subtitle,
  icon: Icon = Construction,
  features = [],
}: {
  title: string;
  subtitle: string;
  icon?: LucideIcon;
  features?: string[];
}) {
  return (
    <AppShell title={title} subtitle={subtitle}>
      <div className="glass-card relative overflow-hidden rounded-3xl p-10">
        <div className="absolute -right-20 -top-20 h-72 w-72 rounded-full bg-primary/15 blur-3xl" />
        <div className="absolute -bottom-24 -left-16 h-72 w-72 rounded-full bg-[oklch(0.68_0.16_300)]/10 blur-3xl" />
        <div className="relative flex flex-col items-start gap-6 md:flex-row md:items-center">
          <div className="grid h-20 w-20 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-primary to-[oklch(0.68_0.16_300)] text-white shadow-[0_20px_40px_-12px_oklch(0.63_0.19_258/0.5)]">
            <Icon className="h-9 w-9" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="inline-flex items-center gap-2 rounded-full bg-primary/15 px-3 py-1 text-[11px] font-semibold uppercase tracking-widest text-primary">
              <Sparkles className="h-3.5 w-3.5" /> Module ready
            </div>
            <h2 className="mt-3 text-2xl font-bold md:text-3xl">{title}</h2>
            <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
              {subtitle}
            </p>
          </div>
        </div>

        {features.length > 0 && (
          <div className="relative mt-8 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {features.map((f) => (
              <div
                key={f}
                className="rounded-xl border border-border/60 bg-background/40 p-4"
              >
                <div className="text-[10px] font-semibold uppercase tracking-widest text-primary">
                  Capability
                </div>
                <div className="mt-1 text-sm font-medium">{f}</div>
              </div>
            ))}
          </div>
        )}
      </div>
    </AppShell>
  );
}
