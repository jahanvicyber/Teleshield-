import { Bell, Search, PanelLeft, Sun, Moon, ChevronDown } from "lucide-react";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export function TopBar({
  onToggle,
  onOpenNotifications,
}: {
  onToggle: () => void;
  onOpenNotifications: () => void;
}) {
  const [now, setNow] = useState(new Date());
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  return (
    <header className="sticky top-0 z-30 flex h-16 items-center gap-3 border-b border-border/60 bg-background/70 px-4 backdrop-blur-xl md:px-6">
      <Button
        variant="ghost"
        size="icon"
        onClick={onToggle}
        className="shrink-0"
      >
        <PanelLeft className="h-5 w-5" />
      </Button>

      <div className="relative hidden max-w-md flex-1 md:block">
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <input
          placeholder="Search numbers, cases, evidence, officers…"
          className="h-10 w-full rounded-lg border border-border/60 bg-card/60 pl-9 pr-16 text-sm outline-none ring-primary/40 placeholder:text-muted-foreground focus:ring-2"
        />
        <kbd className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 rounded border border-border/60 bg-muted/60 px-1.5 py-0.5 text-[10px] text-muted-foreground">
          ⌘K
        </kbd>
      </div>

      <div className="ml-auto flex items-center gap-2">
        <div className="hidden items-center gap-2 rounded-lg border border-border/60 bg-card/50 px-3 py-1.5 text-xs lg:flex">
          <span className="h-2 w-2 rounded-full bg-success pulse-ring" />
          <span className="font-mono tabular-nums text-foreground/90">
            {now.toLocaleTimeString("en-IN", { hour12: false })}
          </span>
          <span className="text-muted-foreground">IST</span>
        </div>

        <Button variant="ghost" size="icon" className="text-muted-foreground">
          <Sun className="h-5 w-5 rotate-0 scale-0 transition-all dark:rotate-0 dark:scale-0" />
          <Moon className="h-5 w-5" />
        </Button>

        <Button
          variant="ghost"
          size="icon"
          className="relative"
          onClick={onOpenNotifications}
        >
          <Bell className="h-5 w-5" />
          <span className="absolute right-1.5 top-1.5 grid h-4 min-w-4 place-items-center rounded-full bg-destructive px-1 text-[10px] font-bold text-white">
            4
          </span>
        </Button>

        <div className="hidden h-9 items-center gap-3 rounded-lg border border-border/60 bg-card/50 px-2 pl-2.5 sm:flex">
          <div className="grid h-7 w-7 place-items-center rounded-md bg-gradient-to-br from-primary to-[oklch(0.68_0.16_300)] text-[11px] font-bold text-white">
            VI
          </div>
          <div className="hidden text-left leading-tight md:block">
            <div className="text-xs font-semibold">DySP. V. Iyer</div>
            <div className="flex items-center gap-1.5 text-[10px] text-muted-foreground">
              <Badge
                variant="outline"
                className="h-4 border-primary/40 bg-primary/10 px-1.5 text-[9px] font-semibold uppercase tracking-wider text-primary"
              >
                Admin
              </Badge>
              Cyber Cell · Mumbai
            </div>
          </div>
          <ChevronDown className="h-4 w-4 text-muted-foreground" />
        </div>
      </div>
    </header>
  );
}
