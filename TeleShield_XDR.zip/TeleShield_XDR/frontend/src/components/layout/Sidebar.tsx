import { Link, useRouterState } from "@tanstack/react-router";
import {
  LayoutDashboard,
  ScanLine,
  PhoneCall,
  Sparkles,
  Globe2,
  Folder,
  FileLock2,
  FileText,
  BarChart3,
  Map,
  Ban,
  ShieldCheck,
  ScrollText,
  Bell,
  Users,
  Settings,
  LogOut,
  ShieldHalf,
} from "lucide-react";
import { cn } from "@/lib/utils";

const nav = [
  { to: "/", label: "Dashboard", icon: LayoutDashboard },
  { to: "/scanner", label: "Call Scanner", icon: ScanLine },
  { to: "/call-logs", label: "Call Logs", icon: PhoneCall },
  { to: "/ai-detection", label: "AI Detection", icon: Sparkles },
  { to: "/threat-intelligence", label: "Threat Intelligence", icon: Globe2 },
  { to: "/cases", label: "Case Management", icon: Folder },
  { to: "/evidence", label: "Evidence", icon: FileLock2 },
  { to: "/reports", label: "Reports", icon: FileText },
  { to: "/analytics", label: "Analytics", icon: BarChart3 },
  { to: "/maps", label: "Maps", icon: Map },
  { to: "/blacklist", label: "Blacklist", icon: Ban },
  { to: "/whitelist", label: "Whitelist", icon: ShieldCheck },
  { to: "/audit-logs", label: "Audit Logs", icon: ScrollText },
  { to: "/notifications", label: "Notifications", icon: Bell },
  { to: "/users", label: "Users", icon: Users },
  { to: "/settings", label: "Settings", icon: Settings },
] as const;

export function Sidebar({ collapsed }: { collapsed: boolean }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  return (
    <aside
      className={cn(
        "sticky top-0 h-screen shrink-0 border-r border-sidebar-border bg-sidebar/95 backdrop-blur-xl transition-[width] duration-300",
        collapsed ? "w-[76px]" : "w-[260px]",
      )}
    >
      <div className="flex h-16 items-center gap-3 border-b border-sidebar-border px-4">
        <div className="relative grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-primary to-[oklch(0.68_0.16_300)] shadow-[0_0_20px_-4px_oklch(0.63_0.19_258/0.7)]">
          <ShieldHalf className="h-5 w-5 text-white" />
          <span className="absolute -right-0.5 -top-0.5 h-2 w-2 rounded-full bg-success pulse-ring" />
        </div>
        {!collapsed && (
          <div className="min-w-0">
            <div className="truncate text-sm font-bold tracking-wide text-sidebar-foreground">
              TeleShield XDR
            </div>
            <div className="truncate text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
              Cyber Ops · Gov
            </div>
          </div>
        )}
      </div>

      <nav className="flex h-[calc(100vh-8rem)] flex-col gap-0.5 overflow-y-auto px-2 py-3">
        {nav.map(({ to, label, icon: Icon }) => {
          const active =
            to === "/" ? pathname === "/" : pathname.startsWith(to);
          return (
            <Link
              key={to}
              to={to}
              className={cn(
                "group relative flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-all",
                active
                  ? "bg-sidebar-accent text-sidebar-accent-foreground shadow-[inset_1px_0_0_0_var(--primary)]"
                  : "text-sidebar-foreground/70 hover:bg-sidebar-accent/60 hover:text-sidebar-foreground",
                collapsed && "justify-center px-0",
              )}
            >
              {active && (
                <span className="absolute left-0 top-1/2 h-6 w-[3px] -translate-y-1/2 rounded-r-full bg-primary shadow-[0_0_12px_var(--primary)]" />
              )}
              <Icon
                className={cn(
                  "h-[18px] w-[18px] shrink-0",
                  active ? "text-primary" : "",
                )}
              />
              {!collapsed && <span className="truncate">{label}</span>}
            </Link>
          );
        })}
      </nav>

      <div className="absolute inset-x-0 bottom-0 border-t border-sidebar-border p-2">
        <Link
          to="/login"
          className={cn(
            "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm text-sidebar-foreground/70 hover:bg-destructive/15 hover:text-destructive",
            collapsed && "justify-center px-0",
          )}
        >
          <LogOut className="h-[18px] w-[18px]" />
          {!collapsed && <span>Logout</span>}
        </Link>
      </div>
    </aside>
  );
}
