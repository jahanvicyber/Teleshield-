import { createFileRoute } from "@tanstack/react-router";

type ChatMessage = { role: "system" | "user" | "assistant"; content: string };

const SYSTEM_PROMPT = `You are TeleShield Assistant, an in-app AI helper for TeleShield XDR — a cybersecurity platform used by Cyber Crime Cells, Digital Forensics Labs, CERT teams, and Telecom Fraud Investigation Units.

Help investigators with:
- Navigating the platform (Dashboard, Cases, Evidence, Scanner, AI Detection, Call Logs, Blacklist/Whitelist, Threat Intelligence, Maps, Analytics, Reports, Users, Audit Logs).
- Explaining telecom fraud patterns (SIM swap, OTP phishing, vishing, IRSF, Wangiri, spoofing).
- Guidance on evidence handling, chain of custody, and investigation workflows.
- Interpreting risk scores and threat indicators.

Be concise, professional, and precise. Use markdown for structure when useful.`;

export const Route = createFileRoute("/api/chat")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const key = process.env.LOVABLE_API_KEY;
        if (!key)
          return new Response("Missing LOVABLE_API_KEY", { status: 500 });

        const { messages } = (await request.json()) as {
          messages?: ChatMessage[];
        };
        if (!Array.isArray(messages)) {
          return new Response("messages required", { status: 400 });
        }

        const res = await fetch(
          "https://ai.gateway.lovable.dev/v1/chat/completions",
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "Lovable-API-Key": key,
            },
            body: JSON.stringify({
              model: "google/gemini-3.5-flash",
              messages: [
                { role: "system", content: SYSTEM_PROMPT },
                ...messages,
              ],
            }),
          },
        );

        if (!res.ok) {
          const text = await res.text();
          return new Response(text || "Gateway error", { status: res.status });
        }

        const data = (await res.json()) as {
          choices?: Array<{ message?: { content?: string } }>;
        };
        const content = data.choices?.[0]?.message?.content ?? "";
        return Response.json({ content });
      },
    },
  },
});
