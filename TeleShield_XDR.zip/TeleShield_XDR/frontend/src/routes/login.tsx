import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { ShieldHalf, Lock, Mail, Fingerprint, ArrowRight } from "lucide-react";
import { useState } from "react";

export const Route = createFileRoute("/login")({
  head: () => ({
    meta: [
      { title: "Sign in — TeleShield XDR" },
      {
        name: "description",
        content:
          "Secure login to the TeleShield XDR government cyber investigation platform.",
      },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: LoginPage,
});

function LoginPage() {
  const nav = useNavigate();
  const [loading, setLoading] = useState(false);
  return (
    <div className="relative min-h-screen overflow-hidden bg-background">
      {/* Animated network background */}
      <svg
        className="absolute inset-0 h-full w-full opacity-40"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <radialGradient id="bg" cx="50%" cy="0%" r="80%">
            <stop offset="0%" stopColor="oklch(0.63 0.19 258 / 0.4)" />
            <stop offset="100%" stopColor="transparent" />
          </radialGradient>
          <pattern
            id="grid"
            width="40"
            height="40"
            patternUnits="userSpaceOnUse"
          >
            <path
              d="M40 0L0 0 0 40"
              fill="none"
              stroke="oklch(1 0 0 / 0.04)"
              strokeWidth="1"
            />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#grid)" />
        <rect width="100%" height="100%" fill="url(#bg)" />
        {Array.from({ length: 30 }).map((_, i) => {
          const x = Math.random() * 1600;
          const y = Math.random() * 900;
          return (
            <circle
              key={i}
              cx={x}
              cy={y}
              r={Math.random() * 2 + 1}
              fill="oklch(0.63 0.19 258)"
              opacity={0.5}
            >
              <animate
                attributeName="opacity"
                values="0.2;0.9;0.2"
                dur={`${3 + Math.random() * 3}s`}
                repeatCount="indefinite"
              />
            </circle>
          );
        })}
      </svg>

      <div className="relative grid min-h-screen lg:grid-cols-2">
        {/* Left brand */}
        <div className="relative hidden flex-col justify-between p-12 lg:flex">
          <div className="flex items-center gap-3">
            <div className="relative grid h-11 w-11 place-items-center rounded-xl bg-gradient-to-br from-primary to-[oklch(0.68_0.16_300)] shadow-[0_0_30px_-4px_oklch(0.63_0.19_258/0.7)]">
              <ShieldHalf className="h-6 w-6 text-white" />
            </div>
            <div>
              <div className="text-sm font-bold tracking-wide">
                TeleShield XDR
              </div>
              <div className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
                Govt. Cyber Ops
              </div>
            </div>
          </div>

          <div className="max-w-lg">
            <h1 className="text-4xl font-bold leading-tight md:text-5xl">
              Extended detection <br />
              for{" "}
              <span className="bg-gradient-to-r from-primary to-[oklch(0.78_0.16_180)] bg-clip-text text-transparent">
                telecom fraud
              </span>
            </h1>
            <p className="mt-4 text-sm text-muted-foreground">
              Unified AI risk scoring, live investigation feeds, and court-grade
              evidence workflows for Cyber Crime Cells, CERT teams and digital
              forensics labs.
            </p>
            <div className="mt-8 grid max-w-md grid-cols-3 gap-3">
              {[
                { k: "98.4%", v: "AI accuracy" },
                { k: "24/7", v: "SOC uplink" },
                { k: "L4", v: "Clearance" },
              ].map((s) => (
                <div key={s.v} className="glass-card rounded-xl p-3">
                  <div className="text-lg font-bold">{s.k}</div>
                  <div className="text-[10px] uppercase tracking-wider text-muted-foreground">
                    {s.v}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="text-[11px] text-muted-foreground">
            © 2026 TeleShield · Restricted. Unauthorised access is punishable
            under IT Act §66.
          </div>
        </div>

        {/* Right form */}
        <div className="flex items-center justify-center p-6 lg:p-12">
          <div className="glass-card w-full max-w-md rounded-2xl p-8">
            <div className="mb-6 flex items-center gap-2 text-[11px] font-semibold uppercase tracking-widest text-success">
              <span className="h-2 w-2 rounded-full bg-success pulse-ring" />
              Secure channel · TLS 1.3
            </div>
            <h2 className="text-2xl font-bold">Officer sign-in</h2>
            <p className="mt-1 text-sm text-muted-foreground">
              Use your service credentials to continue.
            </p>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                setLoading(true);
                setTimeout(() => nav({ to: "/" }), 700);
              }}
              className="mt-6 space-y-4"
            >
              <label className="block">
                <span className="mb-1.5 block text-xs font-medium text-muted-foreground">
                  Official email
                </span>
                <div className="relative">
                  <Mail className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <input
                    type="email"
                    defaultValue="v.iyer@cybercell.gov.in"
                    className="h-11 w-full rounded-lg border border-border/60 bg-background/60 pl-10 pr-3 text-sm outline-none focus:ring-2 focus:ring-primary/50"
                  />
                </div>
              </label>
              <label className="block">
                <span className="mb-1.5 block text-xs font-medium text-muted-foreground">
                  Password
                </span>
                <div className="relative">
                  <Lock className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <input
                    type="password"
                    defaultValue="••••••••••"
                    className="h-11 w-full rounded-lg border border-border/60 bg-background/60 pl-10 pr-3 text-sm outline-none focus:ring-2 focus:ring-primary/50"
                  />
                </div>
              </label>
              <div className="flex items-center justify-between text-xs">
                <label className="flex items-center gap-2 text-muted-foreground">
                  <input
                    type="checkbox"
                    className="h-3.5 w-3.5 rounded border-border/60 bg-background"
                    defaultChecked
                  />
                  Trust this device
                </label>
                <a className="text-primary hover:underline" href="#">
                  Forgot password?
                </a>
              </div>
              <button
                disabled={loading}
                className="group flex h-11 w-full items-center justify-center gap-2 rounded-lg bg-gradient-to-r from-primary to-[oklch(0.68_0.16_300)] text-sm font-semibold text-white shadow-[0_10px_30px_-8px_oklch(0.63_0.19_258/0.6)] transition-transform hover:scale-[1.01] disabled:opacity-70"
              >
                {loading ? (
                  "Authenticating…"
                ) : (
                  <>
                    Secure sign-in{" "}
                    <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
                  </>
                )}
              </button>
              <button
                type="button"
                className="flex h-11 w-full items-center justify-center gap-2 rounded-lg border border-border/60 bg-background/50 text-sm hover:bg-muted/40"
              >
                <Fingerprint className="h-4 w-4 text-primary" /> Continue with
                hardware key
              </button>
            </form>

            <div className="mt-6 text-center text-[11px] text-muted-foreground">
              Need access?{" "}
              <Link to="/" className="text-primary hover:underline">
                Request from your SPOC
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
