import { createFileRoute } from "@tanstack/react-router";
import { PagePlaceholder } from "@/components/layout/PagePlaceholder";
import { Bell } from "lucide-react";
export const Route = createFileRoute("/notifications")({
  component: () => (
    <PagePlaceholder
      title="Notifications"
      icon={Bell}
      subtitle="All alerts across cases, evidence, and threat intel — filterable and archivable."
      features={[
        "Multi-channel delivery",
        "Priority routing",
        "Snooze rules",
        "Digest mode",
        "Escalation ladders",
        "Silent hours",
      ]}
    />
  ),
});
