import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/layout/AppShell";
import {
  ThreatTrendChart,
  RiskDonut,
  ScamCategoriesChart,
  CarrierChart,
} from "@/components/dashboard/Charts";

export const Route = createFileRoute("/analytics")({
  component: () => (
    <AppShell
      title="Analytics"
      subtitle="Interactive dashboards for trend, cohort, and carrier deep-dives"
    >
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <ThreatTrendChart />
        </div>
        <RiskDonut />
        <ScamCategoriesChart />
        <div className="lg:col-span-2">
          <CarrierChart />
        </div>
      </div>
    </AppShell>
  ),
});
