import { createFileRoute } from "@tanstack/react-router";
import { PagePlaceholder } from "@/components/layout/PagePlaceholder";
import { ScanLine } from "lucide-react";
export const Route = createFileRoute("/scanner")({
  component: () => (
    <PagePlaceholder
      title="Call Scanner"
      icon={ScanLine}
      subtitle="Deep-inspect any inbound call for spoofing, VoIP origin, and scam-pattern fingerprints in under 400ms."
      features={[
        "Real-time carrier lookup",
        "Voice biometrics match",
        "Language & script detection",
        "Origin geolocation",
        "Spoof / CLI-refile detection",
        "One-click escalation",
      ]}
    />
  ),
});
