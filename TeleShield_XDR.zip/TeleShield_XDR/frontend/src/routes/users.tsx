import { createFileRoute } from "@tanstack/react-router";
import { PagePlaceholder } from "@/components/layout/PagePlaceholder";
import { Users } from "lucide-react";
export const Route = createFileRoute("/users")({
  component: () => (
    <PagePlaceholder
      title="User Management"
      icon={Users}
      subtitle="Manage officers, clearances, and role bindings across cyber cells."
      features={[
        "RBAC + ABAC",
        "Clearance levels",
        "MFA enforcement",
        "Session control",
        "Delegation",
        "Onboarding workflow",
      ]}
    />
  ),
});
