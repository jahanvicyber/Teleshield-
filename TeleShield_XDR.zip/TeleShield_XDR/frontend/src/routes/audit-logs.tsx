import { createFileRoute } from "@tanstack/react-router";
import { PagePlaceholder } from "@/components/layout/PagePlaceholder";
import { ScrollText } from "lucide-react";
export const Route = createFileRoute("/audit-logs")({
  component: () => (
    <PagePlaceholder
      title="Audit Logs"
      icon={ScrollText}
      subtitle="Immutable trail of every officer action, evidence access, and policy change."
      features={[
        "Immutable ledger",
        "Signed events",
        "Time-travel replay",
        "Export for CAG",
        "Anomaly alerts",
        "Role-scoped views",
      ]}
    />
  ),
});
