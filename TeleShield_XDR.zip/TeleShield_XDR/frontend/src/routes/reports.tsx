import { createFileRoute } from "@tanstack/react-router";
import { PagePlaceholder } from "@/components/layout/PagePlaceholder";
import { FileText } from "lucide-react";
export const Route = createFileRoute("/reports")({
  component: () => (
    <PagePlaceholder
      title="Reports"
      icon={FileText}
      subtitle="Automated periodic briefs and court-ready dossiers, generated from live investigation data."
      features={[
        "Weekly threat brief",
        "Court dossier builder",
        "Custom templates",
        "PDF / DOCX export",
        "Digital signatures",
        "Scheduled delivery",
      ]}
    />
  ),
});
