import { createFileRoute } from "@tanstack/react-router";
import { PagePlaceholder } from "@/components/layout/PagePlaceholder";
import { Sparkles } from "lucide-react";
export const Route = createFileRoute("/ai-detection")({
  component: () => (
    <PagePlaceholder
      title="AI Detection"
      icon={Sparkles}
      subtitle="Explainable AI models classifying scam patterns with confidence scoring and factor attribution."
      features={[
        "Model registry",
        "SHAP explanations",
        "A/B model routing",
        "Confidence thresholds",
        "Feedback loop",
        "Drift monitoring",
      ]}
    />
  ),
});
