import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/layout/AppShell";
import { EvidenceWidget } from "@/components/dashboard/Widgets";
import { UploadCloud, Fingerprint, ShieldCheck } from "lucide-react";

export const Route = createFileRoute("/evidence")({ component: EvidencePage });

function EvidencePage() {
  return (
    <AppShell
      title="Evidence Vault"
      subtitle="Tamper-evident storage with SHA-256 hashing and chain-of-custody"
    >
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="glass-card rounded-2xl p-6 lg:col-span-1">
          <div className="grid h-12 w-12 place-items-center rounded-xl bg-primary/15 text-primary">
            <UploadCloud className="h-6 w-6" />
          </div>
          <h3 className="mt-4 text-lg font-semibold">Upload evidence</h3>
          <p className="mt-1 text-sm text-muted-foreground">
            Drop audio, screenshots, PDFs or images. Hashes generated on ingest.
          </p>
          <div className="mt-4 rounded-xl border-2 border-dashed border-border/60 bg-background/40 p-6 text-center text-sm text-muted-foreground">
            Drag files here or <span className="text-primary">browse</span>
          </div>
          <div className="mt-4 space-y-2 text-xs">
            <div className="flex items-center gap-2">
              <Fingerprint className="h-3.5 w-3.5 text-primary" /> SHA-256 +
              BLAKE3 hashing
            </div>
            <div className="flex items-center gap-2">
              <ShieldCheck className="h-3.5 w-3.5 text-success" /> Chain of
              custody sealed on upload
            </div>
          </div>
        </div>
        <div className="lg:col-span-2">
          <EvidenceWidget />
        </div>
      </div>
    </AppShell>
  );
}
