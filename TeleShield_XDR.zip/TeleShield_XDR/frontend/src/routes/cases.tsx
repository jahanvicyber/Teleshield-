import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/layout/AppShell";
import { CasesWidget } from "@/components/dashboard/Widgets";
import { Folder, Plus, Filter, Download } from "lucide-react";

export const Route = createFileRoute("/cases")({ component: CasesPage });

function CasesPage() {
  return (
    <AppShell
      title="Case Management"
      subtitle="Track investigations from intake to court-ready dossier"
    >
      <div className="mb-4 flex flex-wrap items-center gap-2">
        <button className="inline-flex items-center gap-2 rounded-lg bg-gradient-to-r from-primary to-[oklch(0.68_0.16_300)] px-3.5 py-2 text-sm font-semibold text-white shadow-[0_10px_30px_-10px_oklch(0.63_0.19_258/0.7)]">
          <Plus className="h-4 w-4" /> New case
        </button>
        <button className="inline-flex items-center gap-2 rounded-lg border border-border/60 bg-card/60 px-3 py-2 text-sm">
          <Filter className="h-4 w-4" /> Filters
        </button>
        <button className="inline-flex items-center gap-2 rounded-lg border border-border/60 bg-card/60 px-3 py-2 text-sm">
          <Download className="h-4 w-4" /> Export
        </button>
        <div className="ml-auto flex items-center gap-3 text-xs">
          {[
            "All 76",
            "Critical 12",
            "In Review 24",
            "Court Prep 8",
            "Closed 32",
          ].map((t, i) => (
            <span
              key={t}
              className={`rounded-full px-3 py-1 ${i === 0 ? "bg-primary/20 text-primary" : "bg-muted/40 text-muted-foreground"}`}
            >
              {t}
            </span>
          ))}
        </div>
      </div>
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <CasesWidget />
        </div>
        <div className="glass-card rounded-2xl p-5">
          <div className="mb-3 flex items-center gap-2 text-sm font-semibold">
            <Folder className="h-4 w-4 text-primary" /> Workload
          </div>
          {[
            { n: "DySP. V. Iyer", c: 8, p: 78 },
            { n: "Insp. R. Menon", c: 12, p: 92 },
            { n: "Insp. A. Roy", c: 6, p: 54 },
            { n: "SI. P. Kaur", c: 9, p: 66 },
            { n: "Insp. D. Shah", c: 4, p: 34 },
          ].map((o) => (
            <div key={o.n} className="mb-3 last:mb-0">
              <div className="flex justify-between text-xs">
                <span>{o.n}</span>
                <span className="text-muted-foreground">{o.c} open</span>
              </div>
              <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-muted/40">
                <div
                  className="h-full bg-gradient-to-r from-primary to-warning"
                  style={{ width: `${o.p}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>
    </AppShell>
  );
}
