import { createFileRoute } from "@tanstack/react-router";
import { PagePlaceholder } from "@/components/layout/PagePlaceholder";
import { Ban } from "lucide-react";
export const Route = createFileRoute("/blacklist")({
  component: () => (
    <PagePlaceholder
      title="Blacklist"
      icon={Ban}
      subtitle="Hard-blocked numbers, IMEIs, carriers, and country codes with audit trail."
      features={[
        "Bulk import",
        "Expiry rules",
        "Reason codes",
        "Carrier propagation",
        "Court order tagging",
        "Approval workflow",
      ]}
    />
  ),
});
