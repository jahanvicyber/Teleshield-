import { createFileRoute } from "@tanstack/react-router";
import { PagePlaceholder } from "@/components/layout/PagePlaceholder";
import { PhoneCall } from "lucide-react";
export const Route = createFileRoute("/call-logs")({
  component: () => (
    <PagePlaceholder
      title="Call Logs"
      icon={PhoneCall}
      subtitle="Searchable, filterable ledger of every analysed call with export to CDR format."
      features={[
        "Advanced filters",
        "CDR export",
        "Timeline reconstruction",
        "Cross-carrier joins",
        "Bulk tagging",
        "Retention policies",
      ]}
    />
  ),
});
