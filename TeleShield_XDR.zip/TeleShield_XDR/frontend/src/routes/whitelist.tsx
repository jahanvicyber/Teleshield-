import { createFileRoute } from "@tanstack/react-router";
import { PagePlaceholder } from "@/components/layout/PagePlaceholder";
import { ShieldCheck } from "lucide-react";
export const Route = createFileRoute("/whitelist")({
  component: () => (
    <PagePlaceholder
      title="Whitelist"
      icon={ShieldCheck}
      subtitle="Trusted government helplines and verified enterprise CLIs, exempt from AI scoring."
      features={[
        "Verified issuer badges",
        "Enterprise onboarding",
        "Auto-renewal",
        "Attestation records",
        "Signed CLI proofs",
        "Public directory sync",
      ]}
    />
  ),
});
