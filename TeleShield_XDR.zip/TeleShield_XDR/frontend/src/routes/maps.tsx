import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/layout/AppShell";
import { IndiaMap } from "@/components/dashboard/IndiaMap";
export const Route = createFileRoute("/maps")({
  component: () => (
    <AppShell
      title="Geospatial Maps"
      subtitle="State-wise incident density and cross-border origin tracing"
    >
      <IndiaMap />
    </AppShell>
  ),
});
