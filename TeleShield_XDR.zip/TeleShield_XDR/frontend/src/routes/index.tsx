import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/layout/AppShell";
import { KpiGrid } from "@/components/dashboard/KpiGrid";
import {
  ThreatTrendChart,
  RiskDonut,
  ScamCategoriesChart,
  CarrierChart,
} from "@/components/dashboard/Charts";
import { AiRiskPanel } from "@/components/dashboard/AiRiskPanel";
import {
  LiveFeed,
  CasesWidget,
  EvidenceWidget,
  ThreatIntelWidget,
} from "@/components/dashboard/Widgets";
import { IndiaMap } from "@/components/dashboard/IndiaMap";

export const Route = createFileRoute("/")({
  component: DashboardPage,
});

function DashboardPage() {
  return (
    <AppShell
      title="Command Center"
      subtitle="Live telecom threat intelligence · Cyber Cell Mumbai · Clearance L4"
    >
      <div className="space-y-6">
        <KpiGrid />

        <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
          <div className="xl:col-span-2">
            <AiRiskPanel />
          </div>
          <LiveFeed />
        </div>

        <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <ThreatTrendChart />
          </div>
          <RiskDonut />
        </div>

        <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
          <ScamCategoriesChart />
          <CarrierChart />
        </div>

        <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
          <div className="xl:col-span-2">
            <IndiaMap />
          </div>
          <ThreatIntelWidget />
        </div>

        <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
          <CasesWidget />
          <EvidenceWidget />
        </div>
      </div>
    </AppShell>
  );
}
