import { createFileRoute } from "@tanstack/react-router";
import { PagePlaceholder } from "@/components/layout/PagePlaceholder";
import { Settings } from "lucide-react";
export const Route = createFileRoute("/settings")({
  component: () => (
    <PagePlaceholder
      title="Settings"
      icon={Settings}
      subtitle="Platform, retention, integration, and security policy configuration."
      features={[
        "Retention policies",
        "SIEM integrations",
        "SSO / SAML",
        "Webhook endpoints",
        "Encryption keys",
        "Feature flags",
      ]}
    />
  ),
});
