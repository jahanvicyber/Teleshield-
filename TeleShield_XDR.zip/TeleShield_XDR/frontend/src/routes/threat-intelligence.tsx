import { createFileRoute } from "@tanstack/react-router";
import { PagePlaceholder } from "@/components/layout/PagePlaceholder";
import { Globe2 } from "lucide-react";
export const Route = createFileRoute("/threat-intelligence")({
  component: () => (
    <PagePlaceholder
      title="Threat Intelligence"
      icon={Globe2}
      subtitle="Curated global feeds of known scam numbers, carriers, and TTPs with STIX/TAXII sync."
      features={[
        "Global feed sync",
        "IOC search",
        "Actor profiles",
        "Carrier reputation",
        "STIX / TAXII export",
        "Custom watchlists",
      ]}
    />
  ),
});
