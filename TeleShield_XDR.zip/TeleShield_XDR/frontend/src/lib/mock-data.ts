export const kpis = [
  {
    key: "calls",
    label: "Total Calls Analysed",
    value: 128473,
    delta: 12.4,
    icon: "Phone",
  },
  {
    key: "high",
    label: "High Risk Calls",
    value: 3821,
    delta: 8.1,
    icon: "AlertTriangle",
    tone: "warning" as const,
  },
  {
    key: "critical",
    label: "Critical Threats",
    value: 214,
    delta: -3.2,
    icon: "ShieldAlert",
    tone: "danger" as const,
  },
  { key: "cases", label: "Open Cases", value: 76, delta: 4.5, icon: "Folder" },
  {
    key: "evidence",
    label: "Evidence Uploaded",
    value: 1942,
    delta: 22.7,
    icon: "FileLock2",
    tone: "success" as const,
  },
  {
    key: "accuracy",
    label: "AI Detection Accuracy",
    value: 98.4,
    suffix: "%",
    delta: 0.6,
    icon: "Sparkles",
  },
  {
    key: "online",
    label: "Investigators Online",
    value: 42,
    delta: 5,
    icon: "Users",
    tone: "success" as const,
  },
  {
    key: "pending",
    label: "Pending Reports",
    value: 18,
    delta: -12,
    icon: "FileText",
    tone: "warning" as const,
  },
];

export const dailyTrend = Array.from({ length: 14 }, (_, i) => ({
  day: `D${i + 1}`,
  threats: Math.round(80 + Math.sin(i / 2) * 30 + Math.random() * 40),
  blocked: Math.round(60 + Math.cos(i / 2) * 25 + Math.random() * 30),
}));

export const scamCategories = [
  { name: "KYC Fraud", value: 32 },
  { name: "OTP Scam", value: 24 },
  { name: "Loan Bait", value: 18 },
  { name: "Job Offer", value: 14 },
  { name: "Impersonation", value: 12 },
];

export const riskDistribution = [
  { name: "Critical", value: 214, color: "var(--destructive)" },
  { name: "High", value: 3821, color: "var(--warning)" },
  { name: "Medium", value: 12043, color: "var(--primary)" },
  { name: "Low", value: 98120, color: "var(--success)" },
];

export const carriers = [
  { name: "Airtel", flagged: 412 },
  { name: "Jio", flagged: 388 },
  { name: "Vi", flagged: 221 },
  { name: "BSNL", flagged: 156 },
  { name: "MTNL", flagged: 42 },
];

export const liveFeed = [
  {
    id: "INV-9821",
    number: "+91 98•••••342",
    risk: "Critical",
    officer: "Insp. R. Menon",
    time: "12s ago",
    status: "Analysing",
  },
  {
    id: "INV-9820",
    number: "+91 87•••••118",
    risk: "High",
    officer: "SI. P. Kaur",
    time: "48s ago",
    status: "Escalated",
  },
  {
    id: "INV-9819",
    number: "+44 20•••••7712",
    risk: "High",
    officer: "Insp. A. Roy",
    time: "1m ago",
    status: "Assigned",
  },
  {
    id: "INV-9818",
    number: "+91 74•••••882",
    risk: "Medium",
    officer: "Insp. D. Shah",
    time: "2m ago",
    status: "Analysing",
  },
  {
    id: "INV-9817",
    number: "+1 415•••••229",
    risk: "Critical",
    officer: "DySP. V. Iyer",
    time: "3m ago",
    status: "Evidence",
  },
  {
    id: "INV-9816",
    number: "+91 90•••••441",
    risk: "Low",
    officer: "SI. M. Khan",
    time: "4m ago",
    status: "Closed",
  },
  {
    id: "INV-9815",
    number: "+880 17•••••09",
    risk: "High",
    officer: "Insp. R. Menon",
    time: "6m ago",
    status: "Assigned",
  },
];

export const cases = [
  {
    id: "CS-2041",
    title: "OTP Interception Ring — Mumbai",
    priority: "Critical",
    officer: "DySP. V. Iyer",
    status: "In Review",
    progress: 72,
    due: "18 Nov",
  },
  {
    id: "CS-2040",
    title: "Cross-border KYC Fraud",
    priority: "High",
    officer: "Insp. A. Roy",
    status: "Investigating",
    progress: 45,
    due: "22 Nov",
  },
  {
    id: "CS-2039",
    title: "Loan App Extortion Cluster",
    priority: "High",
    officer: "Insp. R. Menon",
    status: "Evidence",
    progress: 88,
    due: "16 Nov",
  },
  {
    id: "CS-2038",
    title: "Impersonation — Tax Dept.",
    priority: "Medium",
    officer: "SI. P. Kaur",
    status: "Investigating",
    progress: 30,
    due: "29 Nov",
  },
  {
    id: "CS-2037",
    title: "SIM Box Detection — Delhi NCR",
    priority: "Critical",
    officer: "Insp. D. Shah",
    status: "Court Prep",
    progress: 95,
    due: "14 Nov",
  },
];

export const evidence = [
  {
    id: "EV-7712",
    type: "Audio",
    name: "call_9821.wav",
    size: "3.2 MB",
    hash: "0x8f…c412",
    custody: "Verified",
    time: "2m",
  },
  {
    id: "EV-7711",
    type: "Image",
    name: "screenshot_ui.png",
    size: "1.1 MB",
    hash: "0x2a…9911",
    custody: "Verified",
    time: "9m",
  },
  {
    id: "EV-7710",
    type: "PDF",
    name: "transcript_9820.pdf",
    size: "482 KB",
    hash: "0xdd…7f02",
    custody: "Pending",
    time: "18m",
  },
  {
    id: "EV-7709",
    type: "Audio",
    name: "call_9817.wav",
    size: "5.7 MB",
    hash: "0x11…aa20",
    custody: "Verified",
    time: "27m",
  },
  {
    id: "EV-7708",
    type: "Image",
    name: "sms_thread.png",
    size: "820 KB",
    hash: "0x4c…12ef",
    custody: "Verified",
    time: "41m",
  },
];

export const threatIntel = [
  {
    number: "+234 80•••••112",
    country: "Nigeria",
    carrier: "MTN",
    score: 98,
    reports: 421,
  },
  {
    number: "+92 30•••••441",
    country: "Pakistan",
    carrier: "Jazz",
    score: 96,
    reports: 388,
  },
  {
    number: "+880 17•••••09",
    country: "Bangladesh",
    carrier: "Robi",
    score: 92,
    reports: 302,
  },
  {
    number: "+1 415•••••229",
    country: "USA",
    carrier: "AT&T",
    score: 88,
    reports: 221,
  },
  {
    number: "+44 20•••••771",
    country: "UK",
    carrier: "EE",
    score: 84,
    reports: 174,
  },
];

export const notifications = [
  {
    id: 1,
    title: "Critical threat detected",
    body: "INV-9821 flagged with risk 98/100",
    time: "just now",
    tone: "danger" as const,
  },
  {
    id: 2,
    title: "Case assigned",
    body: "CS-2041 → DySP. V. Iyer",
    time: "3m",
    tone: "primary" as const,
  },
  {
    id: 3,
    title: "Evidence verified",
    body: "EV-7712 chain of custody sealed",
    time: "9m",
    tone: "success" as const,
  },
  {
    id: 4,
    title: "Report generated",
    body: "Weekly threat brief ready",
    time: "22m",
    tone: "warning" as const,
  },
];
