# TeleShield XDR — Backend (ab poori tarah se bana hua hai)

## Kya thik kiya gaya (What was broken, fixed)

Aapki zip mein `backend/app/` ke andar folders (`core`, `models`, `schemas`,
`services`, `api`) sab **khaali (0 bytes)** the, jabki `main.py` aur
`models/__init__.py` unhi files se import kar rahe the — isi wajah se app
start hi nahi ho raha tha (`ImportError` / `ModuleNotFoundError`).

Maine poora backend likh diya hai:

- **Auth**: JWT login/refresh/logout, password hashing (bcrypt), role-based
  access control.
- **Models (DB tables)**: User, Role, Case, Evidence + Chain-of-Custody,
  Call Logs, Blacklist/Whitelist, Fraud Patterns + AI Scan Results,
  Threat Intelligence, Reports, Notifications, Audit Logs.
- **13 API modules**, jo frontend ke sidebar modules se match karte hain:
  `/api/auth`, `/api/users`, `/api/cases`, `/api/evidence`,
  `/api/call-logs`, `/api/blacklist`, `/api/whitelist`, `/api/scanner`,
  `/api/threat-intelligence`, `/api/reports`, `/api/notifications`,
  `/api/analytics`, `/api/audit-logs`.
- **AI Scanner engine**: ek deterministic rule/keyword based scoring engine
  (`app/services/scanner_service.py`) jo call/number ka risk score nikaalta
  hai — isko baad me real ML model se replace kar sakte ho, sirf ek function
  badalna padega.
- **`requirements.txt` mein missing packages add kiye**: `pydantic-settings`,
  `email-validator`, `python-multipart`, `alembic` — inke bina app crash ho
  raha tha.
- **`docker-compose.yml`** (pehle khaali tha) — ab Postgres + backend dono
  ek command me chal jaate hain.
- Startup par tables auto-create hote hain aur ek **default admin user**
  + kuch **fraud detection patterns** seed ho jaate hain.

> ⚠️ Is sandbox mein mujhe internet access nahi hai, isliye main
> `pip install` ya server run karke live test nahi kar saka. Maine har
> file ko Python ke syntax checker se verify kiya hai (koi typo/syntax
> error nahi hai), aur saare imports manually cross-check kiye hain.
> Pehli baar run karte waqt agar koi chhoti si dependency-version wali
> dikkat aaye, mujhe error message bhejo, turant fix kar dunga.

---

## Kaise chalayein (How to run)

### Option A — Docker (sabse aasan, recommended)

```bash
cd TeleShield_XDR
docker compose up --build
```

- Backend: http://localhost:8000
- Swagger API docs (yahan se saare endpoints test kar sakte ho, bina
  frontend ke bhi): http://localhost:8000/docs
- Postgres apne aap DB `teleshield_xdr` bana lega.

### Option B — Manually (bina Docker)

1. **PostgreSQL** local mein install/run karo aur ek DB bana lo:
   ```sql
   CREATE DATABASE teleshield_xdr;
   ```
   Agar username/password/port alag hai to `backend/.env` mein
   `DATABASE_URL` update kar dena.

2. **Backend setup**:
   ```bash
   cd TeleShield_XDR/backend
   python -m venv venv
   source venv/bin/activate        # Windows: venv\Scripts\activate
   pip install -r requirements.txt
   python -m app.run
   ```
   Ya seedha: `uvicorn app.main:app --reload`

3. Backend chalte hi terminal me ek warning dikhegi jisme default admin
   credentials print honge:
   - Employee ID: `ADMIN001`
   - Password: `ChangeMe@123`
   - Sabse pehla kaam: `/api/auth/login` se login karke
     `/api/auth/change-password` se ye password turant badal do.

4. **Frontend** (already bana hua hai, sirf packages install karke chalao):
   ```bash
   cd TeleShield_XDR/frontend
   npm install       # ya: bun install
   npm run dev       # ya: bun run dev
   ```
   Note: frontend abhi filhaal `libs/mock-data.ts` se dummy data dikhata
   hai; backend se connect karne ke liye frontend me API calls (fetch/axios)
   add karni hongi jo `http://localhost:8000/api/...` endpoints ko hit
   karein. Agar chaho to main ye wiring bhi kar sakta hoon — bata dena.

---

## Software ka use kaise karein (How to use it)

1. **Login**: `POST /api/auth/login` — body me `employee_id` aur
   `password` bhejo, response me `access_token` milega.
2. Us token ko har request ke `Authorization: Bearer <token>` header me
   bhejo (Swagger UI me upar "Authorize" button se paste kar sakte ho).
3. **Naya investigator/user banane ke liye** (sirf Administrator role
   kar sakta hai): `POST /api/users`
4. **Case kholna**: `POST /api/cases` — case number (e.g. `CS-1234`)
   apne aap generate ho jaata hai.
5. **Call analyse karna** (AI scam detection): `POST /api/call-logs` —
   phone number bhejo, chaho to `transcript` bhi bhejo (jo bhi call/SMS
   text hai) — engine automatically risk score + risk level (Low/Medium/
   High/Critical) nikaal dega, blacklist/whitelist ko bhi check karega.
6. **Evidence upload karna**: `POST /api/evidence` — case se link karo,
   phir `POST /api/evidence/{id}/custody` se custody events (Verified,
   Transferred, Archived...) add karte jao — poora chain-of-custody
   record ban jaata hai.
7. **Blacklist/Whitelist manage karna**: `POST /api/blacklist` ya
   `POST /api/whitelist` — number + reason.
8. **Dashboard/analytics dekhna**: `GET /api/analytics/dashboard` — KPIs,
   daily trend, scam category breakdown, risk distribution — sab ek
   response me.
9. **Reports banwana**: `POST /api/reports` (title, type, case).
10. **Audit trail dekhna** (Admin/Auditor/Supervisor only):
    `GET /api/audit-logs` — har login, case-create, evidence-upload
    action yahan record hota hai.

Sabse aasan tarika sab test karne ka: server chalao aur
**http://localhost:8000/docs** kholo — wahan har endpoint "Try it out"
button ke saath hai, koi Postman ki bhi zarurat nahi.

---

## Aage kya baaki hai (Still to do, agar chahiye)

- Frontend ko in APIs se actually connect karna (abhi frontend sirf mock
  data use kar raha hai).
- File upload ko real object storage (`evidence-storage/` folder ya S3/
  MinIO) se properly wire karna — abhi sirf metadata store hota hai.
- Alembic migrations set up karna (abhi tables `create_all()` se seedhe
  ban jaate hain, jo dev ke liye theek hai par production ke liye migration
  history rakhna better hota hai).
- Real AI/ML model scanner engine se jodna (abhi rule-based hai).

Bata do agar in me se koi bhi cheez next me karni ho.
